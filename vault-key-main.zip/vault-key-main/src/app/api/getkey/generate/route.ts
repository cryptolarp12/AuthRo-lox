import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { generateKey } from "@/lib/keys";
import {
  getRequesterIp,
  checkBlacklist,
  addToBlacklist,
} from "@/lib/lootlabs";

/**
 * POST /api/getkey/generate
 *
 * Generates the final key after all checkpoints are completed.
 * Public endpoint (no auth). The key is created with userId = null
 * (anonymous) and bound to the script.
 *
 * Body: { sessionId: string }
 *
 * Returns: {
 *   key: string,
 *   expiresAt: string,
 *   script: { id, name, version }
 * }
 */
export async function POST(req: NextRequest) {
  const ip = getRequesterIp(req);

  // Check blacklist
  const blacklisted = await checkBlacklist({ ip });
  if (blacklisted) {
    const remainingMs = blacklisted.expiresAt.getTime() - Date.now();
    const remainingHours = Math.ceil(remainingMs / (60 * 60 * 1000));
    return NextResponse.json(
      {
        error: `You are blacklisted for ${remainingHours}h`,
        blacklisted: true,
      },
      { status: 403 }
    );
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { sessionId } = body || {};

  if (!sessionId) {
    return NextResponse.json(
      { error: "sessionId is required" },
      { status: 400 }
    );
  }

  // Load the session
  const session = await db.getKeySession.findUnique({
    where: { id: sessionId },
    include: { script: true },
  });

  if (!session) {
    return NextResponse.json(
      { error: "Session not found" },
      { status: 404 }
    );
  }

  // Verify session is COMPLETED (anti-bypass — can't generate without completing checkpoints)
  if (session.status !== "COMPLETED") {
    await addToBlacklist({
      ip,
      reason: "generate_without_completion",
    });
    return NextResponse.json(
      {
        error:
          "All checkpoints must be completed before generating a key. Blacklisted for 24h.",
        blacklisted: true,
      },
      { status: 400 }
    );
  }

  // Check session hasn't expired
  if (session.expiresAt < new Date()) {
    await db.getKeySession.update({
      where: { id: sessionId },
      data: { status: "EXPIRED" },
    });
    return NextResponse.json(
      { error: "Session has expired. Please start a new one." },
      { status: 400 }
    );
  }

  // Check if key was already generated for this session (idempotency)
  if (session.keyId) {
    const existingKey = await db.key.findUnique({
      where: { id: session.keyId },
    });
    if (existingKey) {
      return NextResponse.json({
        key: existingKey.key,
        expiresAt: existingKey.expiresAt,
        script: {
          id: session.script.id,
          name: session.script.name,
          version: session.script.version,
        },
        alreadyGenerated: true,
      });
    }
  }

  // Generate a new key
  const expiresAt = new Date(
    Date.now() + session.durationHours * 60 * 60 * 1000
  );

  let attempts = 0;
  let keyId: string | null = null;
  let keyValue: string | null = null;

  while (attempts < 5) {
    const candidate = generateKey("XXXXX-XXXXX-XXXXX-XXXXX");
    const exists = await db.key.findUnique({
      where: { key: candidate },
      select: { id: true },
    });
    if (!exists) {
      const created = await db.key.create({
        data: {
          key: candidate,
          userId: null, // anonymous
          scriptId: session.scriptId,
          status: "ACTIVE",
          expiresAt,
          usageLimit: 100,
          usageCount: 0,
          note: `Generated via /getkey flow (${session.durationHours}h)`,
          sessionId: session.id,
          ipAddress: ip,
        },
      });
      keyId = created.id;
      keyValue = candidate;
      break;
    }
    attempts++;
  }

  if (!keyValue || !keyId) {
    return NextResponse.json(
      { error: "Failed to generate key" },
      { status: 500 }
    );
  }

  // Link the key to the session
  await db.getKeySession.update({
    where: { id: sessionId },
    data: { keyId },
  });

  return NextResponse.json({
    key: keyValue,
    expiresAt,
    script: {
      id: session.script.id,
      name: session.script.name,
      version: session.script.version,
    },
  });
}
