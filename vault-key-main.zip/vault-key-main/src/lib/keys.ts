import crypto from "crypto";

const CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no confusing chars

/**
 * Generate a key based on a template pattern. Use 'X' for random alphanumerics.
 * A checksum digit is appended after a dash.
 *
 * Example: generateKey("XXXXX-XXXXX-XXXXX-XXXXX")
 * => "AB3KD-9F2LM-PQ7RT-XYZ12-7"
 */
export function generateKey(template = "XXXXX-XXXXX-XXXXX-XXXXX"): string {
  let body = "";
  for (let i = 0; i < template.length; i++) {
    const ch = template[i];
    if (ch === "X" || ch === "x") {
      const idx = crypto.randomInt(0, CHARS.length);
      body += CHARS[idx];
    } else {
      body += ch;
    }
  }
  const checksum = calculateChecksum(body);
  return `${body}-${checksum}`;
}

export function calculateChecksum(key: string): string {
  let sum = 0;
  for (let i = 0; i < key.length; i++) {
    sum += key.charCodeAt(i) * (i + 1);
  }
  return (sum % 36).toString(36).toUpperCase();
}

export function validateKeyFormat(key: string): boolean {
  if (!key) return false;
  const lastDash = key.lastIndexOf("-");
  if (lastDash < 1) return false;
  const body = key.slice(0, lastDash);
  const checksum = key.slice(lastDash + 1);
  if (!checksum || checksum.length !== 1) return false;
  return calculateChecksum(body) === checksum.toUpperCase();
}

/**
 * Convert a human-readable duration ("7d", "24h", "30m") into a future Date.
 * Returns null for "never".
 */
export function durationToDate(duration: string): Date | null {
  if (!duration || duration === "never") return null;
  const match = duration.match(/^(\d+)([smhdw])$/);
  if (!match) return null;
  const n = parseInt(match[1], 10);
  const unit = match[2];
  const multipliers: Record<string, number> = {
    s: 1000,
    m: 60 * 1000,
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
  };
  return new Date(Date.now() + n * multipliers[unit]);
}

export function keyStatus(key: {
  status: string;
  expiresAt: Date | null;
  usageLimit: number | null;
  usageCount: number;
}): "ACTIVE" | "EXPIRED" | "REVOKED" | "EXHAUSTED" | "PENDING" {
  if (key.status === "REVOKED") return "REVOKED";
  if (key.status === "PENDING") return "PENDING";
  if (key.expiresAt && key.expiresAt < new Date()) return "EXPIRED";
  if (key.usageLimit !== null && key.usageCount >= key.usageLimit)
    return "EXHAUSTED";
  return "ACTIVE";
}
