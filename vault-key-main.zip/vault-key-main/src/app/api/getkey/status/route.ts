import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getRequesterIp, checkBlacklist } from "@/lib/lootlabs";

/**
 * GET /api/getkey/status?sessionId=...
 *
 * Returns the current state of a /getkey session.
 * Public endpoint.
 */
export async function GET(req: NextRequest) {
  const ip = getRequesterIp(req);
  const url = new URL(req.url);
  const sessionId = url.searchParams.get("sessionId");

  if (!sessionId) {
    return NextResponse.json(
      { error: "sessionId is required" },
      { status: 400 }
    );
  }

  const session = await db.getKeySession.findUnique({
    where: { id: sessionId },
    include: {
      script: {
        select: { id: true, name: true, description: true, version: true },
      },
    },
  });

  if (!session) {
    return NextResponse.json(
      { error: "Session not found" },
      { status: 404 }
    );
  }

  // Verify the session belongs to this IP (or is being accessed from same IP)
  if (session.ipAddress !== ip) {
    return NextResponse.json(
      { error: "Session does not belong to this IP" },
      { status: 403 }
    );
  }

  const blacklisted = await checkBlacklist({ ip });

  const checkpoints = JSON.parse(session.checkpointData);

  // If key already generated, fetch it
  let generatedKey: string | null = null;
  if (session.keyId) {
    const key = await db.key.findUnique({
      where: { id: session.keyId },
      select: { key: true, expiresAt: true },
    });
    if (key) {
      generatedKey = key.key;
    }
  }

  return NextResponse.json({
    sessionId: session.id,
    scriptId: session.scriptId,
    script: session.script,
    durationHours: session.durationHours,
    checkpointsTotal: session.checkpointsTotal,
    checkpointsCompleted: session.checkpointsCompleted,
    checkpoints,
    status: session.status,
    expiresAt: session.expiresAt,
    blacklisted: blacklisted
      ? { expiresAt: blacklisted.expiresAt, reason: blacklisted.reason }
      : null,
    key: generatedKey
      ? { value: generatedKey, expiresAt: session.expiresAt }
      : null,
  });
}
