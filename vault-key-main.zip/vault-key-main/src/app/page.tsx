"use client";

import { useEffect } from "react";
import { useApp } from "@/lib/store";
import { useAuth } from "@/hooks/use-auth";
import { Navbar } from "@/components/keyvault/Navbar";
import { Landing } from "@/components/keyvault/Landing";
import { Dashboard } from "@/components/keyvault/Dashboard";
import { KeysView } from "@/components/keyvault/KeysView";
import { ScriptsView } from "@/components/keyvault/ScriptsView";
import { ScriptEditorView } from "@/components/keyvault/ScriptEditorView";
import { ValidateView } from "@/components/keyvault/ValidateView";

export default function Page() {
  const { view, setView } = useApp();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (user && view === "landing") {
      setView("dashboard");
    }
    if (!user && !loading && view !== "landing" && view !== "validate") {
      setView("landing");
    }
  }, [user, loading, view, setView]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-1">
        {view === "landing" && <Landing />}
        {view === "dashboard" && user && <Dashboard />}
        {view === "keys" && user && <KeysView />}
        {view === "scripts" && user && <ScriptsView />}
        {view === "script-editor" && user && <ScriptEditorView />}
        {view === "validate" && <ValidateView />}
      </main>
    </div>
  );
}
