"use client";

import { useEffect, useState } from "react";
import { useApp } from "@/lib/store";
import { GradientButton } from "./GradientButton";
import {
  KeyRound,
  FileCode2,
  Activity,
  CheckCircle2,
  Clock,
  Ban,
  TrendingUp,
  ArrowRight,
  Ticket,
  ShieldCheck,
  RefreshCw,
  Zap,
} from "./icons";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { toast } from "sonner";

type Stats = {
  totals: {
    keys: number;
    active: number;
    expired: number;
    revoked: number;
    scripts: number;
    verifications: number;
    totalUsage: number;
  };
  usageByDay: { date: string; count: number }[];
  topScripts: { id: string; name: string; count: number }[];
};

export function Dashboard() {
  const { setView } = useApp();
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/stats", { cache: "no-store" });
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch (e) {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const cards = stats
    ? [
        {
          label: "Total Keys",
          value: stats.totals.keys,
          sub: `${stats.totals.active} active`,
          icon: KeyRound,
          gradient: "gradient-primary",
        },
        {
          label: "Active Keys",
          value: stats.totals.active,
          sub: `${stats.totals.expired} expired`,
          icon: CheckCircle2,
          gradient: "gradient-success",
        },
        {
          label: "Total Scripts",
          value: stats.totals.scripts,
          sub: "Hosted",
          icon: FileCode2,
          gradient: "gradient-secondary",
        },
        {
          label: "Total Validations",
          value: stats.totals.totalUsage,
          sub: "All time",
          icon: Activity,
          gradient: "gradient-accent",
        },
      ]
    : [];

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Welcome back. Here&apos;s what&apos;s happening with your keys.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <GradientButton
            variant="outline"
            size="default"
            onClick={load}
            disabled={loading}
          >
            <RefreshCw className={`size-4 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </GradientButton>
          <GradientButton
            variant="primary"
            size="default"
            onClick={() => setView("keys")}
          >
            <KeyRound className="size-4" />
            Manage keys
          </GradientButton>
        </div>
      </div>

      {/* Stat cards */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className="h-28 rounded-xl glass-card shimmer"
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {cards.map((c) => {
            const Icon = c.icon;
            return (
              <Card
                key={c.label}
                className="glass-card relative overflow-hidden"
              >
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    {c.label}
                  </CardTitle>
                  <div
                    className={`size-9 rounded-lg ${c.gradient} flex items-center justify-center`}
                  >
                    <Icon className="size-4 text-white" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{c.value}</div>
                  <p className="text-xs text-muted-foreground mt-1">{c.sub}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Usage chart */}
        <Card className="glass-card lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="size-4 text-primary" />
                  Validations — last 7 days
                </CardTitle>
                <CardDescription>
                  Daily key validation activity
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {stats && stats.usageByDay.length > 0 ? (
              <UsageChart data={stats.usageByDay} />
            ) : (
              <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
                No usage data yet — generate some keys to see activity.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick actions */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="size-4 text-accent" />
              Quick actions
            </CardTitle>
            <CardDescription>
              Jump straight to common tasks
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <ActionRow
              icon={KeyRound}
              title="Generate keys"
              desc="Create new keys with custom templates"
              onClick={() => setView("keys")}
              accent="primary"
            />
            <ActionRow
              icon={FileCode2}
              title="Upload a script"
              desc="Host your script with versioning"
              onClick={() => setView("scripts")}
              accent="secondary"
            />
            <ActionRow
              icon={Ticket}
              title="Get key flow"
              desc="See the /getkey ad-bypass experience"
              onClick={() => setView("getkey")}
              accent="accent"
            />
            <ActionRow
              icon={ShieldCheck}
              title="Test the validator"
              desc="Validate a key against the public API"
              onClick={() => setView("validate")}
              accent="success"
            />
          </CardContent>
        </Card>
      </div>

      {/* Top scripts */}
      {stats && stats.topScripts.length > 0 && (
        <Card className="glass-card mt-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileCode2 className="size-4 text-primary" />
                Top scripts by key count
              </CardTitle>
              <GradientButton
                variant="ghost"
                size="sm"
                onClick={() => setView("scripts")}
              >
                View all
                <ArrowRight className="size-3.5" />
              </GradientButton>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {stats.topScripts.map((s, i) => {
                const max = stats.topScripts[0].count || 1;
                const pct = Math.max(8, Math.round((s.count / max) * 100));
                return (
                  <div key={s.id} className="space-y-1">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground font-mono text-xs">
                          #{i + 1}
                        </span>
                        <span className="font-medium">{s.name}</span>
                      </div>
                      <span className="text-muted-foreground text-xs">
                        {s.count} keys
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-background/60 overflow-hidden">
                      <div
                        className="h-full gradient-primary rounded-full transition-all"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function ActionRow({
  icon: Icon,
  title,
  desc,
  onClick,
  accent,
}: {
  icon: any;
  title: string;
  desc: string;
  onClick: () => void;
  accent: "primary" | "secondary" | "accent" | "success";
}) {
  const grad =
    accent === "primary"
      ? "gradient-primary"
      : accent === "accent"
      ? "gradient-accent"
      : accent === "success"
      ? "gradient-success"
      : "gradient-secondary";
  return (
    <button
      onClick={onClick}
      className="group w-full flex items-center gap-3 p-3 rounded-lg hover:bg-background/40 transition-colors text-left"
    >
      <div
        className={`size-9 rounded-md ${grad} flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform`}
      >
        <Icon className="size-4 text-white" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium">{title}</div>
        <div className="text-xs text-muted-foreground truncate">{desc}</div>
      </div>
      <ArrowRight className="size-4 text-muted-foreground group-hover:text-foreground transition-colors" />
    </button>
  );
}

function UsageChart({ data }: { data: { date: string; count: number }[] }) {
  const max = Math.max(...data.map((d) => d.count), 1);
  return (
    <div className="flex items-end justify-between gap-2 h-48 pt-4">
      {data.map((d) => {
        const h = Math.max(4, Math.round((d.count / max) * 160));
        const date = new Date(d.date);
        const day = date.toLocaleDateString("en-US", {
          weekday: "short",
        });
        return (
          <div
            key={d.date}
            className="flex flex-col items-center gap-2 flex-1 group"
          >
            <div className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
              {d.count}
            </div>
            <div className="w-full flex items-end justify-center h-40">
              <div
                className="w-full max-w-[40px] gradient-primary rounded-t-md transition-all hover:brightness-110"
                style={{ height: `${h}px` }}
                title={`${d.count} on ${d.date}`}
              />
            </div>
            <div className="text-xs text-muted-foreground">{day}</div>
          </div>
        );
      })}
    </div>
  );
}
