import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { generateKey } from "@/lib/keys";
import {
  getRequesterIp,
  checkBlacklist,
  createLootLabsLink,
} from "@/lib/lootlabs";
import crypto from "crypto";

// Session must complete within 30 minutes
const SESSION_TTL_MS = 30 * 60 * 1000;

// Rate limit: max 5 session starts per hour per IP
const sessionStarts = new Map<string, { count: number; resetAt: number }>();

function rateLimit(ip: string): boolean {
  const now = Date.now();
  const bucket = sessionStarts.get(ip);
  if (!bucket || bucket.resetAt < now) {
    sessionStarts.set(ip, { count: 1, resetAt: now + 60 * 60 * 1000 });
    return false;
  }
  bucket.count++;
  return bucket.count > 5;
}

/**
 * POST /api/getkey/start
 *
 * Starts a new /getkey session for a script. Public endpoint (no auth).
 *
 * Body: {
 *   scriptId: string,
 *   durationHours: 12 | 24
 * }
 *
 * Returns: {
 *   sessionId: string,
 *   checkpoints: [{ index, url, linkId, fallback }]
 * }
 *
 * The user must visit each checkpoint URL, complete the ad, and paste
 * their completion token via /api/getkey/checkpoint.
 */
export async function POST(req: NextRequest) {
  const ip = getRequesterIp(req);

  // Rate limit
  if (rateLimit(ip)) {
    return NextResponse.json(
      { error: "Too many session starts. Please try again later." },
      { status: 429 }
    );
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { scriptId, durationHours } = body || {};

  if (!scriptId) {
    return NextResponse.json({ error: "scriptId is required" }, { status: 400 });
  }

  if (durationHours !== 12 && durationHours !== 24) {
    return NextResponse.json(
      { error: "durationHours must be 12 or 24" },
      { status: 400 }
    );
  }

  // Check blacklist
  const blacklisted = await checkBlacklist({ ip });
  if (blacklisted) {
    const remainingMs = blacklisted.expiresAt.getTime() - Date.now();
    const remainingHours = Math.ceil(remainingMs / (60 * 60 * 1000));
    return NextResponse.json(
      {
        error: `You are blacklisted for ${remainingHours}h due to a previous bypass attempt.`,
        blacklisted: true,
        expiresAt: blacklisted.expiresAt,
        reason: blacklisted.reason,
      },
      { status: 403 }
    );
  }

  // Load the script — must be public and key-required
  const script = await db.script.findFirst({
    where: { id: scriptId },
    select: {
      id: true,
      name: true,
      description: true,
      isPublic: true,
      keyRequired: true,
      userId: true,
    },
  });

  if (!script) {
    return NextResponse.json(
      { error: "Script not found" },
      { status: 404 }
    );
  }

  if (!script.keyRequired) {
    return NextResponse.json(
      { error: "This script is keyless — no key required." },
      { status: 400 }
    );
  }

  // Check for existing in-progress session for this IP + script
  const existing = await db.getKeySession.findFirst({
    where: {
      scriptId,
      ipAddress: ip,
      status: "IN_PROGRESS",
      expiresAt: { gt: new Date() },
    },
  });

  if (existing) {
    // Return the existing session
    const checkpoints = JSON.parse(existing.checkpointData);
    return NextResponse.json({
      sessionId: existing.id,
      durationHours: existing.durationHours,
      checkpointsTotal: existing.checkpointsTotal,
      checkpointsCompleted: existing.checkpointsCompleted,
      checkpoints,
      expiresAt: existing.expiresAt,
      resumed: true,
    });
  }

  // Create new session
  const checkpointsTotal = durationHours === 12 ? 1 : 2;
  const sessionId = crypto.randomBytes(16).toString("hex");
  const now = Date.now();
  const expiresAt = new Date(now + SESSION_TTL_MS);

  // Create LootLabs links for each checkpoint
  // The destination URL is where LootLabs redirects after completion —
  // we send them back to /getkey/[scriptId] with a token query param.
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || `https://${req.headers.get("host") || "localhost:3000"}`;
  const destinationUrl = `${appUrl}/getkey/${scriptId}`;

  const checkpoints: any[] = [];
  for (let i = 0; i < checkpointsTotal; i++) {
    const link = await createLootLabsLink({
      destinationUrl,
      alias: `kv-${sessionId.slice(0, 8)}-cp${i + 1}`,
    });
    checkpoints.push({
      index: i,
      url: link.url,
      linkId: link.linkId,
      fallback: link.fallback,
      completed: false,
      token: null,
    });
  }

  const session = await db.getKeySession.create({
    data: {
      id: sessionId,
      scriptId,
      ipAddress: ip,
      userAgent: req.headers.get("user-agent") || null,
      durationHours,
      checkpointsTotal,
      checkpointsCompleted: 0,
      checkpointData: JSON.stringify(checkpoints),
      status: "IN_PROGRESS",
      expiresAt,
    },
  });

  return NextResponse.json({
    sessionId: session.id,
    durationHours,
    checkpointsTotal,
    checkpointsCompleted: 0,
    checkpoints,
    expiresAt: session.expiresAt,
    resumed: false,
  });
}
