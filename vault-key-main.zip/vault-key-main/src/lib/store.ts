import { create } from "zustand";

export type View =
  | "landing"
  | "dashboard"
  | "keys"
  | "scripts"
  | "script-editor"
  | "getkey"
  | "validate";

type AppState = {
  view: View;
  selectedScriptId: string | null;
  selectedKeyId: string | null;

  setView: (v: View) => void;
  setScriptId: (id: string | null) => void;
  setKeyId: (id: string | null) => void;
};

export const useApp = create<AppState>((set) => ({
  view: "landing",
  selectedScriptId: null,
  selectedKeyId: null,

  setView: (v) => set({ view: v }),
  setScriptId: (id) => set({ selectedScriptId: id }),
  setKeyId: (id) => set({ selectedKeyId: id }),
}));

/**
 * Helper that redirects to Clerk-hosted sign-in / sign-up pages.
 * Call from any client component instead of opening a modal.
 */
export function openAuth(mode: "signin" | "signup" = "signin") {
  if (typeof window === "undefined") return;
  if (mode === "signup") {
    window.location.href = "/sign-up";
  } else {
    window.location.href = "/sign-in";
  }
}
