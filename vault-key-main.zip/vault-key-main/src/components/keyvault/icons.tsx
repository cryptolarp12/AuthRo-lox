export {
  LayoutDashboard,
  KeyRound,
  FileCode2,
  Ticket,
  ShieldCheck,
  LogOut,
  Menu,
  Plus,
  Trash2,
  Copy,
  Check,
  Loader2,
  Sparkles,
  X,
  ChevronRight,
  ChevronLeft,
  Search,
  Filter,
  MoreHorizontal,
  Eye,
  EyeOff,
  RefreshCw,
  ExternalLink,
  AlertCircle,
  CheckCircle2,
  Clock,
  Calendar,
  Activity,
  TrendingUp,
  Users,
  Zap,
  Lock,
  Globe,
  Cpu,
  Code2,
  Download,
  Upload,
  Settings,
  Pencil,
  Save,
  Play,
  ArrowRight,
  ArrowLeft,
  Star,
  Github,
  BookOpen,
  Server,
  Database,
  Fingerprint,
  Ban,
  CircleCheck,
  CircleAlert,
  Info,
  Coins,
  Link2,
} from "lucide-react";

// Custom KeyVault logo (a stylized vault/key hybrid)
export function KeyVaultLogo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <circle cx="8" cy="15" r="4" />
      <path d="M10.85 12.15 19 4" />
      <path d="m18 5 3 3" />
      <path d="m15 8 3 3" />
    </svg>
  );
}
