import { NextRequest, NextResponse } from "next/server";

type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();

type LimiterConfig = {
  windowMs: number;
  max: number;
  keyPrefix: string;
};

/**
 * Simple in-memory rate limiter keyed by IP + path.
 * Not distributed — suitable for a single-instance deployment.
 */
export function rateLimit(cfg: LimiterConfig) {
  return (req: NextRequest): NextResponse | null => {
    const ip =
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      req.headers.get("x-real-ip") ||
      "unknown";

    const key = `${cfg.keyPrefix}:${ip}`;
    const now = Date.now();
    const bucket = buckets.get(key);

    if (!bucket || bucket.resetAt < now) {
      buckets.set(key, { count: 1, resetAt: now + cfg.windowMs });
      return null;
    }

    bucket.count++;
    if (bucket.count > cfg.max) {
      return NextResponse.json(
        {
          error:
            "Too many requests. Please slow down and try again later.",
          retryAfter: Math.ceil((bucket.resetAt - now) / 1000),
        },
        {
          status: 429,
          headers: {
            "Retry-After": String(Math.ceil((bucket.resetAt - now) / 1000)),
          },
        }
      );
    }
    return null;
  };
}

// Pre-configured limiters used by API routes
// Note: Clerk handles rate-limiting on auth endpoints natively.
export const limiters = {
  keyGenerate: rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 20,
    keyPrefix: "kg",
  }),
  validate: rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 60,
    keyPrefix: "vd",
  }),
  verifyAd: rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 10,
    keyPrefix: "va",
  }),
};
