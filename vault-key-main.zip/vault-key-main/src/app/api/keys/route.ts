import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getAuthUser } from "@/lib/auth";
import { generateKey, durationToDate, keyStatus } from "@/lib/keys";
import { limiters } from "@/lib/rate-limit";

// GET /api/keys — list keys for the current user (optionally filtered by scriptId)
export async function GET(req: NextRequest) {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const url = new URL(req.url);
  const scriptId = url.searchParams.get("scriptId");
  const status = url.searchParams.get("status");
  const search = url.searchParams.get("search");

  const where: any = { userId: user.id };
  if (scriptId) where.scriptId = scriptId;

  const keys = await db.key.findMany({
    where,
    include: { script: true },
    orderBy: { createdAt: "desc" },
  });

  let result = keys.map((k) => ({
    ...k,
    computedStatus: keyStatus(k),
  }));

  if (status && status !== "ALL") {
    result = result.filter((k) => k.computedStatus === status);
  }
  if (search) {
    const s = search.toLowerCase();
    result = result.filter(
      (k) =>
        k.key.toLowerCase().includes(s) ||
        (k.note || "").toLowerCase().includes(s) ||
        (k.script?.name || "").toLowerCase().includes(s)
    );
  }

  return NextResponse.json({ keys: result });
}

// POST /api/keys — generate a new key (or batch)
export async function POST(req: NextRequest) {
  const limited = limiters.keyGenerate(req);
  if (limited) return limited;

  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const {
    template = "XXXXX-XXXXX-XXXXX-XXXXX",
    expiresAt,
    usageLimit,
    ipRestriction,
    hardwareId,
    scriptId,
    note,
    count = 1,
  } = body || {};

  if (count > 50) {
    return NextResponse.json(
      { error: "Cannot generate more than 50 keys at once" },
      { status: 400 }
    );
  }

  // Validate template
  if (!/^[Xx\-]*$/.test(template) || template.replace(/[^Xx]/g, "").length < 4) {
    return NextResponse.json(
      { error: "Template must contain at least 4 'X' characters" },
      { status: 400 }
    );
  }

  const expiresAtDate = expiresAt ? durationToDate(expiresAt) : null;
  const limitVal =
    typeof usageLimit === "number" && usageLimit > 0 ? usageLimit : null;

  // If scriptId is provided, ensure it belongs to the user
  if (scriptId) {
    const script = await db.script.findFirst({
      where: { id: scriptId, userId: user.id },
    });
    if (!script) {
      return NextResponse.json(
        { error: "Script not found" },
        { status: 404 }
      );
    }
  }

  const created: any[] = [];
  // Loop to ensure unique keys
  for (let i = 0; i < count; i++) {
    let attempts = 0;
    let key: any = null;
    while (attempts < 5) {
      const candidate = generateKey(template);
      const exists = await db.key.findUnique({
        where: { key: candidate },
        select: { id: true },
      });
      if (!exists) {
        key = await db.key.create({
          data: {
            key: candidate,
            userId: user.id,
            scriptId: scriptId || null,
            status: "ACTIVE",
            expiresAt: expiresAtDate,
            usageLimit: limitVal,
            usageCount: 0,
            ipRestriction: ipRestriction || null,
            hardwareId: hardwareId || null,
            note: note || null,
          },
          include: { script: true },
        });
        key.computedStatus = keyStatus(key);
        created.push(key);
        break;
      }
      attempts++;
    }
  }

  return NextResponse.json({
    success: true,
    keys: created,
    count: created.length,
  });
}

// DELETE /api/keys — bulk delete by IDs
export async function DELETE(req: NextRequest) {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { ids = [] } = body || {};
  if (!Array.isArray(ids) || ids.length === 0) {
    return NextResponse.json({ error: "ids required" }, { status: 400 });
  }

  const result = await db.key.deleteMany({
    where: { id: { in: ids }, userId: user.id },
  });

  return NextResponse.json({ success: true, deleted: result.count });
}
