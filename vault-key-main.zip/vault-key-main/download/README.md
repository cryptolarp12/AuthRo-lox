# KeyVault — Modern Key System Service

A production-style key management service with public `/getkey/[scriptId]` pages, Luarmor-style checkpoint flow, Clerk auth, and a smooth light/dark theme.

## What's New

### Public `/getkey/[scriptId]` Page (No Auth Required)
- Each script gets its own public key-system page at `/getkey/[scriptId]`
- Users pick a duration: **12 hours (1 ad)** or **24 hours (2 ads)**
- Checkpoint loader shows progress (1/2, 2/2, etc.)
- Each checkpoint has a "Go to LootLabs Ad" button that opens a dynamically-created ad link
- After completing the ad, user pastes their `LL_...` completion token
- Token is verified via LootLabs API → checkpoint marked complete
- When all checkpoints done → "Generate My Key" button appears
- Key is created with the chosen expiry (12h or 24h)

### Per-Script Key/Keyless Toggle
- In the Scripts dashboard, every script has a "Require a key" toggle
- **Key required** (default): users must complete the /getkey ad flow
- **Keyless**: `/getkey/[scriptId]` shows the script content directly, no key needed
- Toggle is available in both the create modal and the editor sidebar

### Anti-Bypass System
- Every checkpoint token is verified via the LootLabs API (`LOOTLABS_API_KEY`)
- Tokens can't be reused (anti-replay check across all sessions)
- Checkpoints must be completed in order
- "Generate Key" button only appears after all checkpoints are verified
- Calling `/api/getkey/generate` without completing checkpoints → 24h blacklist
- Failed token verification → 24h blacklist for the IP
- Blacklist is checked on every API call

### LootLabs API Integration
- Ad links are created dynamically via `POST https://api.lootlabs.io/v1/link/create`
- Each checkpoint gets its own unique ad URL
- The destination URL is set to `/getkey/[scriptId]` (so users return after completing)
- Token verification via `POST https://api.lootlabs.io/v1/verify_completion`
- If the API is unreachable, falls back to format-check (`LL_` prefix, ≥16 chars)

## Tech Stack
- Next.js 16 (App Router) + React 19 + TypeScript 5
- Clerk authentication (for creators/dashboard only — /getkey is public)
- Prisma ORM + SQLite (PostgreSQL-compatible)
- Tailwind CSS 4 + shadcn/ui
- next-themes (light + dark)
- Lucide icons

## Public vs Protected Routes

**Public (no auth):**
- `/` — Landing page
- `/getkey` — Lists all public scripts with key systems
- `/getkey/[scriptId]` — The checkpoint flow for a specific script
- `/sign-in`, `/sign-up` — Clerk hosted pages
- `POST /api/validate` — Key validation (used by client scripts)
- `POST /api/getkey/start` — Start a /getkey session
- `POST /api/getkey/checkpoint` — Verify a checkpoint token
- `POST /api/getkey/generate` — Generate the final key
- `GET /api/getkey/status` — Check session status

**Protected (Clerk auth):**
- `/api/me`, `/api/keys/*`, `/api/scripts/*`, `/api/stats` — Dashboard APIs

## The /getkey Flow

```
User visits /getkey/[scriptId]
       │
       ▼
  Script exists & is public?
       │
       ├── No ──► 404 / "not available"
       │
       ▼
  keyRequired = false? ──► Show "No key required" + copy script
       │
       Yes
       ▼
  Step 1: Choose duration
  ┌────────────┐  ┌────────────┐
  │  12 hours   │  │  24 hours   │
  │  1 ad       │  │  2 ads      │
  └────────────┘  └────────────┘
       │
       ▼
  POST /api/getkey/start { scriptId, durationHours }
       │
       ▼
  Server creates GetKeySession
  Server calls LootLabs API to create ad links
  Returns: { sessionId, checkpoints: [{ url, linkId }] }
       │
       ▼
  Step 2: Checkpoint flow
  ┌──────────────────────────────────┐
  │  Progress: 0/2                    │
  │  ● ─── ○ ─── ○                   │
  │                                   │
  │  Checkpoint 1:                    │
  │  [ Go to LootLabs Ad #1 → ]      │
  │  Token: [ LL_xxxxxxxxxxxx ]      │
  │  [ Verify checkpoint ]            │
  │                                   │
  │  Checkpoint 2: (locked)           │
  └──────────────────────────────────┘
       │
       ▼
  User clicks "Go to LootLabs Ad"
  → Opens ad URL in new tab
  → Completes the ad on lootlabs.io
  → Receives completion token (LL_...)
       │
       ▼
  User pastes token → POST /api/getkey/checkpoint
       │
       ├── Check blacklist (24h block)
       ├── Check token not reused
       ├── Verify via LootLabs API
       │
       ├── Invalid ──► Blacklist IP for 24h
       │
       ▼
  Valid! Mark checkpoint complete
  If all done → status = COMPLETED
       │
       ▼
  Step 3: Generate key
  [ 🔑 Generate My Key ]
       │
       ▼
  POST /api/getkey/generate { sessionId }
       │
       ├── Verify session status = COMPLETED (anti-bypass)
       ├── Verify session not expired
       │
       ▼
  Create Key (userId = null, scriptId = bound, expiresAt = now + durationHours)
       │
       ▼
  Display key to user:
  ┌──────────────────────────────────┐
  │  ✅ Your key is ready!            │
  │  XXXXX-XXXXX-XXXXX-XXXXX-X  📋  │
  │  Expires in: 24h                  │
  └──────────────────────────────────┘
```

## Environment Variables

```bash
# Database
DATABASE_URL=file:./db/custom.db

# Clerk
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...
CLERK_WEBHOOK_SECRET=           # from Clerk webhook endpoint

# App URL (for LootLabs redirect destination)
NEXT_PUBLIC_APP_URL=https://your-domain.com

# LootLabs API — creates ad links + verifies completion tokens
LOOTLABS_API_KEY=6d3a2547e53be64453d430914b7892132d41a8abb19b243cc5772d4a44e6b6af

# Bypass blacklist duration (default: 24h)
BYPASS_BLACKLIST_MS=86400000

# Cloudflare Turnstile (optional)
NEXT_PUBLIC_TURNSTILE_SITE_KEY=
TURNSTILE_SECRET_KEY=
```

## API Endpoints

### Public
| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/validate` | Validate a key (used by client scripts) |
| `POST` | `/api/getkey/start` | Start a /getkey session — returns checkpoint URLs |
| `POST` | `/api/getkey/checkpoint` | Verify a checkpoint's completion token |
| `POST` | `/api/getkey/generate` | Generate the final key after all checkpoints |
| `GET` | `/api/getkey/status` | Check session status |
| `POST` | `/api/clerk/webhook` | Clerk user sync webhook |

### Protected (Clerk)
| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/me` | Get current user |
| `GET/POST` | `/api/keys` | List / generate keys |
| `GET/PATCH/DELETE` | `/api/keys/[id]` | Key CRUD |
| `GET/POST` | `/api/scripts` | List / create scripts (supports `keyRequired`) |
| `GET/PATCH/DELETE` | `/api/scripts/[id]` | Script CRUD |
| `GET` | `/api/stats` | Dashboard stats |

## Database Schema

```prisma
model Script {
  // ...
  keyRequired Boolean @default(true)  // if false, /getkey/[id] shows script directly
  luarmorUrl  String?                // legacy field (unused in new flow)
  getkeySessions GetKeySession[]
}

model GetKeySession {
  id                   String  @id @default(cuid())
  scriptId             String
  ipAddress            String
  durationHours        Int     // 12 or 24
  checkpointsTotal     Int     // 1 for 12h, 2 for 24h
  checkpointsCompleted Int     @default(0)
  checkpointData       String  // JSON array of { index, url, linkId, completed, token }
  status               String  @default("IN_PROGRESS") // IN_PROGRESS | COMPLETED | EXPIRED | BLACKLISTED
  expiresAt            DateTime // session must complete within 30 min
  keyId                String? @unique // set when key is generated
  key                  Key?    @relation("SessionKey")
}

model Key {
  // ...
  userId    String?  // nullable — anonymous /getkey keys have userId = null
  sessionId String?  @unique — links to the GetKeySession that created this key
  ipAddress String?  // IP of the creator (for anonymous keys)
}

model Bypass {
  // 24h blacklist for IPs/users that fail verification
  ip        String
  userId    String?
  reason    String   // failed_verification | reused_token | generate_without_completion | etc.
  expiresAt DateTime
}
```

## How to Deploy to Vercel

1. **Push to GitHub** (or your Git provider)
2. Go to https://vercel.com/new
3. Import your repository
4. Add all environment variables (from `.env`) in the Vercel dashboard
5. Deploy — Vercel will detect Next.js automatically
6. After deployment:
   - Update Clerk dashboard → **Domains** → add your Vercel URL
   - Update Clerk dashboard → **Webhooks** → add `https://your-vercel-url/api/clerk/webhook`
   - Update `.env` → `NEXT_PUBLIC_APP_URL=https://your-vercel-url.vercel.app`

## How to Get Cloudflare Turnstile Keys

Clerk already uses Turnstile internally. To get your own keys for custom forms:

1. Go to https://dash.cloudflare.com/?to=/:account/turnstile
2. Click **Add Site**
3. Fill in:
   - Site name: `KeyVault`
   - Domain: your Vercel URL
   - Widget mode: **Managed**
4. Click **Create**
5. Copy both keys:
   - Site Key (`0x4AAAA...`) → `NEXT_PUBLIC_TURNSTILE_SITE_KEY`
   - Secret Key (`0x4AAAA...`) → `TURNSTILE_SECRET_KEY`
