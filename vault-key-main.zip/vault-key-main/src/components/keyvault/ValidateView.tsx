"use client";

import { useState } from "react";
import { GradientButton } from "./GradientButton";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  ShieldCheck,
  Loader2,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  Activity,
  Fingerprint,
  Globe,
  Cpu,
  Play,
  Copy,
  Check,
  Info,
} from "./icons";
import { toast } from "sonner";

type ValidateResult = {
  valid: boolean;
  status?: string;
  message?: string;
  key?: {
    id: string;
    expiresAt: string | null;
    usageLimit: number | null;
    usageCount: number;
  };
  script?: { id: string; name: string; version: string } | null;
  error?: string;
};

const STATUS_COLORS: Record<string, { label: string; cls: string }> = {
  ACTIVE: { label: "Active", cls: "bg-green-500/15 text-green-400 border-green-500/30" },
  EXPIRED: { label: "Expired", cls: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30" },
  EXHAUSTED: { label: "Exhausted", cls: "bg-orange-500/15 text-orange-400 border-orange-500/30" },
  REVOKED: { label: "Revoked", cls: "bg-red-500/15 text-red-400 border-red-500/30" },
  PENDING: { label: "Pending", cls: "bg-blue-500/15 text-blue-400 border-blue-500/30" },
  INVALID_FORMAT: { label: "Invalid format", cls: "bg-red-500/15 text-red-400 border-red-500/30" },
  NOT_FOUND: { label: "Not found", cls: "bg-red-500/15 text-red-400 border-red-500/30" },
  IP_BLOCKED: { label: "IP blocked", cls: "bg-red-500/15 text-red-400 border-red-500/30" },
  HWID_MISMATCH: { label: "HWID mismatch", cls: "bg-red-500/15 text-red-400 border-red-500/30" },
  SCRIPT_MISMATCH: { label: "Script mismatch", cls: "bg-red-500/15 text-red-400 border-red-500/30" },
};

export function ValidateView() {
  const [key, setKey] = useState("");
  const [scriptId, setScriptId] = useState("");
  const [ip, setIp] = useState("");
  const [hardwareId, setHardwareId] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<ValidateResult | null>(null);
  const [copied, setCopied] = useState(false);

  const handleValidate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!key.trim()) return;
    setSubmitting(true);
    setResult(null);
    try {
      const res = await fetch("/api/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          key: key.trim(),
          scriptId: scriptId.trim() || undefined,
          ip: ip.trim() || undefined,
          hardwareId: hardwareId.trim() || undefined,
        }),
      });
      const data: ValidateResult = await res.json();
      setResult(data);
    } catch (e: any) {
      setResult({
        valid: false,
        status: "ERROR",
        message: e?.message || "Network error",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const copyCurl = () => {
    const body = JSON.stringify(
      {
        key: key || "<YOUR_KEY>",
        scriptId: scriptId || undefined,
        ip: ip || undefined,
        hardwareId: hardwareId || undefined,
      },
      null,
      2
    );
    const cmd = `curl -X POST https://keyvault.app/api/validate \\
  -H "Content-Type: application/json" \\
  -d '${body}'`;
    navigator.clipboard.writeText(cmd);
    setCopied(true);
    toast.success("cURL command copied");
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <ShieldCheck className="size-7 text-primary" />
          Key Validator
        </h1>
        <p className="text-muted-foreground mt-1">
          Test the public validation endpoint. This is the same API your scripts
          call at runtime to verify a key.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Validator form */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <KeyRound className="size-4 text-primary" />
              Validate a key
            </CardTitle>
            <CardDescription>
              Enter a key and any optional restrictions to check.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleValidate} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="vkey">Key</Label>
                <Input
                  id="vkey"
                  value={key}
                  onChange={(e) => setKey(e.target.value.toUpperCase())}
                  placeholder="XXXXX-XXXXX-XXXXX-XXXXX-X"
                  className="font-mono bg-background border-border"
                  required
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="vscript" className="flex items-center gap-1.5">
                    <Globe className="size-3.5 text-muted-foreground" />
                    Script ID (optional)
                  </Label>
                  <Input
                    id="vscript"
                    value={scriptId}
                    onChange={(e) => setScriptId(e.target.value)}
                    placeholder="leave blank"
                    className="font-mono text-xs bg-background border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="vip" className="flex items-center gap-1.5">
                    <Globe className="size-3.5 text-muted-foreground" />
                    IP (optional)
                  </Label>
                  <Input
                    id="vip"
                    value={ip}
                    onChange={(e) => setIp(e.target.value)}
                    placeholder="192.168.1.1"
                    className="font-mono text-xs bg-background border-border"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="vhwid" className="flex items-center gap-1.5">
                  <Cpu className="size-3.5 text-muted-foreground" />
                  Hardware ID (optional)
                </Label>
                <Input
                  id="vhwid"
                  value={hardwareId}
                  onChange={(e) => setHardwareId(e.target.value)}
                  placeholder="auto-bind on first use"
                  className="font-mono text-xs bg-background border-border"
                />
              </div>

              <GradientButton
                type="submit"
                variant="primary"
                size="lg"
                className="w-full"
                disabled={submitting || !key.trim()}
              >
                {submitting ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Play className="size-4" />
                )}
                Validate key
              </GradientButton>
            </form>
          </CardContent>
        </Card>

        {/* Result + curl preview */}
        <div className="space-y-4">
          {result ? (
            <Card
              className={`glass-card ${
                result.valid
                  ? "border-green-500/40"
                  : "border-red-500/40"
              }`}
            >
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  {result.valid ? (
                    <CheckCircle2 className="size-5 text-green-500" />
                  ) : (
                    <AlertCircle className="size-5 text-destructive" />
                  )}
                  {result.valid ? "Key is valid" : "Key is invalid"}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Status</span>
                  <Badge
                    variant="outline"
                    className={
                      STATUS_COLORS[result.status || ""]?.cls ||
                      "bg-secondary text-foreground"
                    }
                  >
                    {STATUS_COLORS[result.status || ""]?.label || result.status}
                  </Badge>
                </div>
                {result.message && (
                  <p className="text-xs text-muted-foreground">{result.message}</p>
                )}
                {result.key && (
                  <div className="space-y-2 pt-2 border-t border-border">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Usage</span>
                      <span className="font-mono">
                        {result.key.usageCount}
                        {result.key.usageLimit !== null
                          ? ` / ${result.key.usageLimit}`
                          : " / ∞"}
                      </span>
                    </div>
                    {result.key.expiresAt && (
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">Expires</span>
                        <span>
                          {new Date(result.key.expiresAt).toLocaleString()}
                        </span>
                      </div>
                    )}
                  </div>
                )}
                {result.script && (
                  <div className="flex items-center justify-between text-xs pt-2 border-t border-border">
                    <span className="text-muted-foreground">Script</span>
                    <span>
                      {result.script.name}{" "}
                      <span className="text-muted-foreground">
                        (v{result.script.version})
                      </span>
                    </span>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card className="glass-card">
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <div className="size-12 rounded-xl gradient-primary flex items-center justify-center mb-3">
                  <Activity className="size-6 text-white" />
                </div>
                <p className="text-sm text-muted-foreground max-w-xs">
                  Submit a key to see its validation result, including usage
                  count, expiry, and bound script.
                </p>
              </CardContent>
            </Card>
          )}

          {/* cURL preview */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Fingerprint className="size-4 text-primary" />
                  API usage
                </CardTitle>
                <button
                  onClick={copyCurl}
                  className="size-7 rounded-md hover:bg-card flex items-center justify-center"
                  title="Copy cURL command"
                >
                  {copied ? (
                    <Check className="size-3.5 text-green-500" />
                  ) : (
                    <Copy className="size-3.5 text-muted-foreground" />
                  )}
                </button>
              </div>
              <CardDescription>
                Public endpoint — no auth required.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="text-xs font-mono leading-relaxed overflow-x-auto scrollbar-custom bg-background/60 rounded-md p-3 border border-border">
{`POST /api/validate
Content-Type: application/json

{
  "key": "${key || "<YOUR_KEY>"}"${
    scriptId ? `,
  "scriptId": "${scriptId}"` : ""
  }${
    ip ? `,
  "ip": "${ip}"` : ""
  }${
    hardwareId ? `,
  "hardwareId": "${hardwareId}"` : ""
  }
}`}
              </pre>
              <div className="mt-3 flex items-start gap-2 text-xs text-muted-foreground">
                <Info className="size-3.5 mt-0.5 shrink-0" />
                <p>
                  Rate limited to <strong>60 requests/min</strong> per IP. Each
                  successful validation increments the key&apos;s usage count.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
