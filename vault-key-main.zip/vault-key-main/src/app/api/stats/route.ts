import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getAuthUser } from "@/lib/auth";
import { keyStatus } from "@/lib/keys";

// GET /api/stats — dashboard stats for the current user
export async function GET() {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const [keys, scripts, verifications] = await Promise.all([
    db.key.findMany({
      where: { userId: user.id },
      include: { script: true },
    }),
    db.script.count({ where: { userId: user.id } }),
    db.verificationLog.count({ where: { userId: user.id } }),
  ]);

  const now = new Date();
  const computed = keys.map((k) => keyStatus(k));

  const totalKeys = keys.length;
  const activeKeys = computed.filter((s) => s === "ACTIVE").length;
  const expiredKeys = computed.filter(
    (s) => s === "EXPIRED" || s === "EXHAUSTED"
  ).length;
  const revokedKeys = computed.filter((s) => s === "REVOKED").length;

  const totalUsage = keys.reduce((sum, k) => sum + (k.usageCount || 0), 0);

  // Usage over last 7 days — bucket by day based on lastUsedAt
  const usageByDay: { date: string; count: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
    const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
    const count = keys.filter((k) => {
      if (!k.lastUsedAt) return false;
      const t = k.lastUsedAt.getTime();
      return t >= dayStart.getTime() && t < dayEnd.getTime();
    }).length;
    usageByDay.push({
      date: dayStart.toISOString().slice(0, 10),
      count,
    });
  }

  // Top scripts by key count
  const scriptMap = new Map<string, { name: string; count: number }>();
  for (const k of keys) {
    if (!k.script) continue;
    const entry = scriptMap.get(k.script.id) || {
      name: k.script.name,
      count: 0,
    };
    entry.count++;
    scriptMap.set(k.script.id, entry);
  }
  const topScripts = Array.from(scriptMap.entries())
    .map(([id, v]) => ({ id, ...v }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  return NextResponse.json({
    totals: {
      keys: totalKeys,
      active: activeKeys,
      expired: expiredKeys,
      revoked: revokedKeys,
      scripts,
      verifications,
      totalUsage,
    },
    usageByDay,
    topScripts,
  });
}
