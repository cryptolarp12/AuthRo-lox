import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { Slot } from "@radix-ui/react-slot";
import { cn } from "@/lib/utils";

/**
 * Smooth, calm button styles — no neon, no glow.
 * Variants use the theme tokens so they adapt to light/dark automatically.
 */
const gradientButtonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:ring-2 focus-visible:ring-ring/40 focus-visible:ring-offset-0",
  {
    variants: {
      variant: {
        // Primary — soft, solid brand color
        primary:
          "bg-primary text-primary-foreground hover:bg-primary/90 active:bg-primary/95 shadow-sm",
        // Subtle outline
        outline:
          "border border-border bg-transparent text-foreground hover:bg-accent hover:text-accent-foreground",
        // Ghost (transparent)
        ghost: "text-foreground hover:bg-accent hover:text-accent-foreground",
        // Success — soft green
        success:
          "bg-[var(--success)] text-[var(--success-foreground)] hover:opacity-90 shadow-sm",
        // Warning — soft amber
        warning:
          "bg-[var(--warning)] text-[var(--warning-foreground)] hover:opacity-90 shadow-sm",
        // Destructive
        destructive:
          "bg-destructive text-white hover:bg-destructive/90 shadow-sm",
        // Soft primary — tinted background
        soft: "bg-primary-soft text-primary-hue hover:bg-primary/10",
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md gap-1.5 px-3 text-xs",
        lg: "h-11 rounded-md px-6 text-base",
        xl: "h-12 rounded-md px-8 text-base",
        icon: "size-9",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "default",
    },
  }
);

export function GradientButton({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof gradientButtonVariants> & {
    asChild?: boolean;
  }) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp
      data-slot="gradient-button"
      className={cn(gradientButtonVariants({ variant, size, className }))}
      {...props}
    />
  );
}

export { gradientButtonVariants };
