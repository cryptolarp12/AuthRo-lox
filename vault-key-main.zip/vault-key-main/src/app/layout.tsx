import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ClerkProvider } from "@clerk/nextjs";
import { ThemeProvider } from "@/components/keyvault/ThemeProvider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "KeyVault — Modern Key System Service",
  description:
    "A professional key system service with Clerk authentication, LootLabs ad-bypass verification, and script hosting.",
  keywords: [
    "key system",
    "key management",
    "script hosting",
    "authentication",
    "LootLabs",
    "jnkie alternative",
    "Clerk auth",
  ],
  authors: [{ name: "KeyVault" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "KeyVault — Modern Key System Service",
    description:
      "Generate, validate, and manage keys with ad-bypass verification, script hosting, and a sleek UI.",
    siteName: "KeyVault",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "KeyVault — Modern Key System Service",
    description:
      "Generate, validate, and manage keys with ad-bypass verification, script hosting, and a sleek UI.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <ClerkProvider
      appearance={{
        variables: {
          colorPrimary: "#3B82F6",
          colorText: "#F8FAFC",
          colorBackground: "#1E293B",
          colorInputBackground: "#0F172A",
          colorInputText: "#F8FAFC",
          colorNeutral: "#334155",
          borderRadius: "0.5rem",
          fontFamily: "var(--font-geist-sans), system-ui, sans-serif",
        },
        elements: {
          formButtonPrimary:
            "bg-primary text-primary-foreground hover:bg-primary/90 text-sm font-medium",
          card: "bg-card border-border",
          headerTitle: "text-foreground",
          headerSubtitle: "text-muted-foreground",
          socialButtonsBlockButton:
            "border-border bg-background/50 text-foreground hover:bg-accent",
          formFieldLabel: "text-foreground",
          formFieldInput:
            "bg-background border-border text-foreground placeholder:text-muted-foreground",
          footerActionLink: "text-primary font-medium",
        },
      }}
    >
      <ThemeProvider
        attribute="class"
        defaultTheme="dark"
        enableSystem
        disableTransitionOnChange
      >
        <html lang="en" suppressHydrationWarning>
          <body
            className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen`}
          >
            {children}
            <Toaster />
            <SonnerToaster
              position="bottom-right"
              toastOptions={{
                classNames: {
                  toast: "bg-card border-border text-foreground",
                },
              }}
            />
          </body>
        </html>
      </ThemeProvider>
    </ClerkProvider>
  );
}
