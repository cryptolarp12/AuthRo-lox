"use client";

import { useEffect, useState, useCallback } from "react";
import { useApp } from "@/lib/store";
import { GradientButton } from "./GradientButton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import {
  FileCode2,
  Plus,
  Pencil,
  Trash2,
  KeyRound,
  Loader2,
  Globe,
  Lock,
  Calendar,
  ArrowRight,
  ExternalLink,
} from "./icons";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

type Script = {
  id: string;
  name: string;
  description: string | null;
  language: string;
  version: string;
  isPublic: boolean;
  keyRequired: boolean;
  content: string;
  createdAt: string;
  updatedAt: string;
  _count?: { keys: number };
};

const LANGUAGES = [
  { value: "lua", label: "Lua" },
  { value: "javascript", label: "JavaScript" },
  { value: "python", label: "Python" },
  { value: "text", label: "Plain text" },
];

const DEFAULT_SNIPPETS: Record<string, string> = {
  lua: `-- Your Lua script goes here\nlocal function onLoad()\n  print("Hello from KeyVault!")\nend\n\nonLoad()`,
  javascript: `// Your JavaScript script goes here\nfunction onLoad() {\n  console.log("Hello from KeyVault!");\n}\n\nonLoad();`,
  python: `# Your Python script goes here\ndef on_load():\n    print("Hello from KeyVault!")\n\non_load()`,
  text: `Paste your script here.`,
};

export function ScriptsView() {
  const { setScriptId, setView } = useApp();
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [deleteScript, setDeleteScript] = useState<Script | null>(null);
  const [deleting, setDeleting] = useState(false);

  // New script form
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [language, setLanguage] = useState("lua");
  const [isPublic, setIsPublic] = useState(false);
  const [keyRequired, setKeyRequired] = useState(true);
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/scripts", { cache: "no-store" });
      if (res.ok) {
        const data = await res.json();
        setScripts(data.scripts);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleCreate = async () => {
    if (!name.trim()) {
      toast.error("Script name is required");
      return;
    }
    setCreating(true);
    try {
      const res = await fetch("/api/scripts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          description: description.trim() || null,
          language,
          content: DEFAULT_SNIPPETS[language] || "",
          isPublic,
          keyRequired,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Failed to create script");
        return;
      }
      toast.success("Script created!");
      setCreateOpen(false);
      setName("");
      setDescription("");
      setLanguage("lua");
      setIsPublic(false);
      setKeyRequired(true);
      load();
    } catch (e: any) {
      toast.error(e?.message || "Network error");
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteScript) return;
    setDeleting(true);
    try {
      const res = await fetch(`/api/scripts/${deleteScript.id}`, {
        method: "DELETE",
      });
      if (!res.ok) {
        const data = await res.json();
        toast.error(data.error || "Failed to delete script");
        return;
      }
      toast.success("Script deleted");
      setDeleteScript(null);
      load();
    } finally {
      setDeleting(false);
    }
  };

  const openEditor = (s: Script) => {
    setScriptId(s.id);
    setView("script-editor");
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">Scripts</h1>
          <p className="text-muted-foreground mt-1">
            Host scripts and bind keys to them.{" "}
            <span className="text-foreground">{scripts.length} total</span>
          </p>
        </div>
        <GradientButton variant="primary" onClick={() => setCreateOpen(true)}>
          <Plus className="size-4" />
          New script
        </GradientButton>
      </div>

      {/* Scripts grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-48 rounded-xl glass-card shimmer" />
          ))}
        </div>
      ) : scripts.length === 0 ? (
        <Card className="glass-card">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="size-16 rounded-2xl gradient-secondary flex items-center justify-center mb-4">
              <FileCode2 className="size-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No scripts yet</h3>
            <p className="text-muted-foreground mb-6 max-w-md">
              Create your first script entry. You can paste your code into the
              in-browser editor and bind keys to it.
            </p>
            <GradientButton variant="primary" onClick={() => setCreateOpen(true)}>
              <Plus className="size-4" />
              Create your first script
            </GradientButton>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {scripts.map((s) => (
            <Card
              key={s.id}
              className="glass-card group hover:border-primary/40 transition-all hover:-translate-y-1"
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="size-11 rounded-lg bg-primary flex items-center justify-center group-hover:scale-110 transition-transform">
                    <FileCode2 className="size-5 text-primary-foreground" />
                  </div>
                  <div className="flex flex-wrap items-center gap-1 justify-end">
                    {s.isPublic ? (
                      <span className="inline-flex items-center gap-1 text-xs text-success-hue px-2 py-0.5 rounded bg-success-soft">
                        <Globe className="size-3" />
                        Public
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs text-muted-foreground px-2 py-0.5 rounded bg-secondary/60">
                        <Lock className="size-3" />
                        Private
                      </span>
                    )}
                    <span
                      className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded ${
                        s.keyRequired
                          ? "bg-primary-soft text-primary-hue"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      <KeyRound className="size-3" />
                      {s.keyRequired ? "Key required" : "Keyless"}
                    </span>
                  </div>
                </div>
                <CardTitle className="text-lg mt-3">{s.name}</CardTitle>
                <CardDescription className="line-clamp-2 min-h-[2.5rem]">
                  {s.description || "No description provided"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
                  <span className="px-2 py-0.5 rounded bg-secondary/60 font-mono">
                    {s.language}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="size-3" />
                    {new Date(s.updatedAt).toLocaleDateString()}
                  </span>
                  <span className="flex items-center gap-1">
                    <KeyRound className="size-3" />
                    {s._count?.keys || 0} keys
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <GradientButton
                    variant="primary"
                    size="sm"
                    className="flex-1"
                    onClick={() => openEditor(s)}
                  >
                    <Pencil className="size-3.5" />
                    Edit
                  </GradientButton>
                  {s.isPublic && (
                    <a
                      href={`/getkey/${s.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center size-8 rounded-md border border-border bg-transparent text-foreground hover:bg-accent transition-colors"
                      title="View /getkey page"
                    >
                      <ExternalLink className="size-3.5" />
                    </a>
                  )}
                  <GradientButton
                    variant="outline"
                    size="icon"
                    onClick={() => setDeleteScript(s)}
                    className="hover:border-destructive hover:text-destructive"
                    aria-label="Delete script"
                  >
                    <Trash2 className="size-4" />
                  </GradientButton>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create script modal */}
      <Dialog open={createOpen} onOpenChange={(o) => !o && setCreateOpen(false)}>
        <DialogContent className="sm:max-w-lg bg-card border-border text-foreground">
          <DialogHeader>
            <DialogTitle>Create a new script</DialogTitle>
            <DialogDescription>
              Set up the metadata first — you can edit the code in the next step.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="sname">Name</Label>
              <Input
                id="sname"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="My Awesome Script"
                className="bg-background border-border"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sdesc">Description (optional)</Label>
              <Textarea
                id="sdesc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What does this script do?"
                className="bg-background border-border min-h-[80px]"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="slang">Language</Label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {LANGUAGES.map((l) => (
                      <SelectItem key={l.value} value={l.value}>
                        {l.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="spublic">Visibility</Label>
                <Select
                  value={isPublic ? "public" : "private"}
                  onValueChange={(v) => setIsPublic(v === "public")}
                >
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="private">Private</SelectItem>
                    <SelectItem value="public">Public</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Key system toggle */}
            <div className="rounded-lg border border-border bg-muted/30 p-4 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <Label htmlFor="skeyreq" className="text-sm font-medium">
                    Require a key to use this script
                  </Label>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {keyRequired
                      ? "Users must complete the /getkey ad flow to receive a key."
                      : "Keyless — users can access the script directly without a key."}
                  </p>
                </div>
                <Switch
                  id="skeyreq"
                  checked={keyRequired}
                  onCheckedChange={setKeyRequired}
                />
              </div>
              {!keyRequired && (
                <div className="rounded-md bg-success-soft p-2 text-xs text-success-hue">
                  ✓ Keyless mode — /getkey/[scriptId] will show the script directly
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <GradientButton
              variant="outline"
              onClick={() => setCreateOpen(false)}
              disabled={creating}
            >
              Cancel
            </GradientButton>
            <GradientButton
              variant="primary"
              onClick={handleCreate}
              disabled={creating}
            >
              {creating && <Loader2 className="size-4 animate-spin" />}
              Create script
            </GradientButton>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog
        open={!!deleteScript}
        onOpenChange={(o) => !o && setDeleteScript(null)}
      >
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete &ldquo;{deleteScript?.name}&rdquo;?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the script. Keys bound to it will
              remain but become unbound. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting && <Loader2 className="size-4 animate-spin mr-2" />}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
