import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getAuthUser } from "@/lib/auth";
import { keyStatus } from "@/lib/keys";

// GET /api/keys/[id]
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const key = await db.key.findFirst({
    where: { id, userId: user.id },
    include: { script: true },
  });
  if (!key) {
    return NextResponse.json({ error: "Key not found" }, { status: 404 });
  }
  return NextResponse.json({ key: { ...key, computedStatus: keyStatus(key) } });
}

// PATCH /api/keys/[id] — update status / note / etc.
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const existing = await db.key.findFirst({
    where: { id, userId: user.id },
  });
  if (!existing) {
    return NextResponse.json({ error: "Key not found" }, { status: 404 });
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const data: any = {};
  if (typeof body.status === "string" && ["ACTIVE", "REVOKED", "PENDING"].includes(body.status)) {
    data.status = body.status;
  }
  if (typeof body.note === "string") data.note = body.note;
  if (typeof body.usageLimit === "number") data.usageLimit = body.usageLimit;
  if (typeof body.ipRestriction === "string") data.ipRestriction = body.ipRestriction || null;
  if (typeof body.hardwareId === "string") data.hardwareId = body.hardwareId || null;

  const updated = await db.key.update({
    where: { id },
    data,
    include: { script: true },
  });
  return NextResponse.json({
    key: { ...updated, computedStatus: keyStatus(updated) },
  });
}

// DELETE /api/keys/[id]
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const existing = await db.key.findFirst({
    where: { id, userId: user.id },
  });
  if (!existing) {
    return NextResponse.json({ error: "Key not found" }, { status: 404 });
  }

  await db.key.delete({ where: { id } });
  return NextResponse.json({ success: true });
}
