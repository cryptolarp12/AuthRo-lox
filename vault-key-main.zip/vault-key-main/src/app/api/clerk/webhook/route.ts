import { NextRequest, NextResponse } from "next/server";
import { Webhook } from "svix";
import { db } from "@/lib/db";

// Clerk webhook handler — syncs user creation/updates/deletion into our DB.
// Configure this URL in Clerk Dashboard → Webhooks → Add Endpoint.
// Subscribe to: user.created, user.updated, user.deleted
//
// After creating the endpoint, copy the "Signing Secret" (whsec_...) and
// set it as CLERK_WEBHOOK_SECRET in your .env file.

export async function POST(req: NextRequest) {
  const WEBHOOK_SECRET = process.env.CLERK_WEBHOOK_SECRET;

  if (!WEBHOOK_SECRET) {
    return NextResponse.json(
      { error: "CLERK_WEBHOOK_SECRET not configured" },
      { status: 500 }
    );
  }

  // Get the headers
  const svix_id = req.headers.get("svix-id");
  const svix_timestamp = req.headers.get("svix-timestamp");
  const svix_signature = req.headers.get("svix-signature");

  if (!svix_id || !svix_timestamp || !svix_signature) {
    return NextResponse.json(
      { error: "Missing svix headers" },
      { status: 400 }
    );
  }

  // Get the body
  const payload = await req.json();
  const body = JSON.stringify(payload);

  // Verify the webhook signature
  const wh = new Webhook(WEBHOOK_SECRET);
  let evt: any;

  try {
    evt = wh.verify(body, {
      "svix-id": svix_id,
      "svix-timestamp": svix_timestamp,
      "svix-signature": svix_signature,
    });
  } catch (err) {
    return NextResponse.json(
      { error: "Invalid webhook signature" },
      { status: 400 }
    );
  }

  const eventType = evt.type;
  const data = evt.data;

  try {
    if (eventType === "user.created" || eventType === "user.updated") {
      const clerkId = data.id;
      const email = data.email_addresses?.[0]?.email_address || "";
      const username =
        data.username ||
        `${data.first_name || ""} ${data.last_name || ""}`.trim() ||
        email.split("@")[0] ||
        "user";
      const avatar = data.image_url || null;

      if (!clerkId) {
        return NextResponse.json(
          { error: "Missing clerkId" },
          { status: 400 }
        );
      }

      // Upsert by clerkId
      await db.user.upsert({
        where: { clerkId },
        create: {
          clerkId,
          email,
          username,
          avatar,
        },
        update: {
          email,
          username,
          avatar,
        },
      });
    } else if (eventType === "user.deleted") {
      const clerkId = data.id;
      if (clerkId) {
        await db.user.deleteMany({ where: { clerkId } }).catch(() => {});
      }
    }

    return NextResponse.json({ success: true, eventType });
  } catch (err: any) {
    return NextResponse.json(
      { error: err?.message || "Webhook handler failed" },
      { status: 500 }
    );
  }
}
