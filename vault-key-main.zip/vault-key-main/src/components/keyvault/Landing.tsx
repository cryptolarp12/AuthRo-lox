"use client";

import { useApp, openAuth } from "@/lib/store";
import { GradientButton } from "./GradientButton";
import {
  KeyRound,
  ShieldCheck,
  Zap,
  FileCode2,
  Ticket,
  Activity,
  Globe,
  Cpu,
  ArrowRight,
  Sparkles,
  Lock,
  Server,
  Check,
} from "./icons";

const FEATURES = [
  {
    icon: KeyRound,
    title: "Template-based key generation",
    desc: "Generate keys with custom patterns like XXXXX-XXXXX-XXXXX-XXXXX. Each key gets a built-in checksum digit for tamper resistance.",
    accent: "primary" as const,
  },
  {
    icon: ShieldCheck,
    title: "Ad-bypass verification flow",
    desc: "Built-in LootLabs & Linkvertise integration. The /getkey endpoint enforces ad completion before issuing a key — with 24h validity windows.",
    accent: "accent" as const,
  },
  {
    icon: FileCode2,
    title: "Script hosting & versioning",
    desc: "Bind keys to scripts. Push script updates with version tracking. Multi-language support (Lua, JavaScript, Python).",
    accent: "secondary" as const,
  },
  {
    icon: Activity,
    title: "Real-time validation API",
    desc: "Public /api/validate endpoint with rate limiting, IP restriction, and HWID binding. Your scripts can verify keys in <50ms.",
    accent: "success" as const,
  },
  {
    icon: Cpu,
    title: "Hardware ID binding",
    desc: "Optionally lock each key to a specific machine. Prevent key sharing and abuse without compromising user experience.",
    accent: "primary" as const,
  },
  {
    icon: Globe,
    title: "IP restriction & geofencing",
    desc: "Restrict keys to specific IPs or CIDR ranges. Perfect for region-locked scripts or beta-testing pools.",
    accent: "secondary" as const,
  },
];

const STEPS = [
  {
    n: "01",
    title: "Sign up",
    desc: "Create your free KeyVault account. No credit card required — authentication is handled via a Clerk-style session.",
  },
  {
    n: "02",
    title: "Upload your script",
    desc: "Create a script entry, paste your code, and pick a language. Everything is stored encrypted at rest.",
  },
  {
    n: "03",
    title: "Generate keys",
    desc: "Use the dashboard to generate keys with custom templates, expiry, and usage limits — or batch generate up to 50 at once.",
  },
  {
    n: "04",
    title: "Share the /getkey link",
    desc: "Users complete an ad-gate via LootLabs/Linkvertise, then receive a key tied to your script automatically.",
  },
];

const STATS = [
  { value: "<50ms", label: "Validation latency" },
  { value: "99.9%", label: "API uptime SLA" },
  { value: "24h", label: "Ad-bypass validity" },
  { value: "50/batch", label: "Key generation" },
];

export function Landing() {
  const { setView } = useApp();

  return (
    <div className="relative">
      {/* Hero */}
      <section className="relative overflow-hidden">
        {/* Background grid — subtle */}
        <div className="absolute inset-0 bg-grid opacity-30" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 pt-20 pb-24 sm:pt-28 sm:pb-32">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/40 backdrop-blur px-4 py-1.5 text-xs font-medium text-muted-foreground mb-6">
              <Sparkles className="size-3.5 text-primary-hue" />
              Modern key system service
            </div>

            <h1 className="text-4xl sm:text-6xl font-bold tracking-tight leading-tight">
              The key system service
              <br />
              built for{" "}
              <span className="gradient-primary-text">script creators</span>
            </h1>

            <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Generate, validate, and manage keys with ad-bypass verification,
              script hosting, and a sleek gradient UI. Built on Next.js with
              Clerk-style authentication and PostgreSQL-grade reliability.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <GradientButton
                variant="primary"
                size="xl"
                onClick={() => openAuth("signup")}
              >
                Start free
                <ArrowRight className="size-4" />
              </GradientButton>
              <GradientButton
                variant="outline"
                size="xl"
                onClick={() => setView("validate")}
              >
                <ShieldCheck className="size-4" />
                Try the validator
              </GradientButton>
            </div>

            <p className="mt-4 text-xs text-muted-foreground">
              No credit card required · 5 keys/day free tier · Cancel anytime
            </p>
          </div>

          {/* Stats row */}
          <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-4">
            {STATS.map((s) => (
              <div
                key={s.label}
                className="glass-card rounded-xl p-5 text-center"
              >
                <div className="text-2xl sm:text-3xl font-bold gradient-primary-text">
                  {s.value}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold">
            Everything you need to{" "}
            <span className="gradient-primary-text">monetize scripts</span>
          </h2>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            Stop rebuilding the same key-system infrastructure. KeyVault handles
            authentication, validation, ad verification, and script hosting in
            one sleek package.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURES.map((f) => {
            const Icon = f.icon;
            const gradient =
              f.accent === "primary"
                ? "gradient-primary"
                : f.accent === "accent"
                ? "gradient-accent"
                : f.accent === "success"
                ? "gradient-success"
                : "gradient-secondary";
            return (
              <div
                key={f.title}
                className="group glass-card rounded-xl p-6 transition-all hover:border-primary/40 hover:-translate-y-1"
              >
                <div
                  className={`size-11 rounded-lg ${gradient} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                >
                  <Icon className="size-5 text-primary-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {f.desc}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* How it works */}
      <section className="relative overflow-hidden border-y border-border bg-card/30">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 py-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold">
              Four steps to{" "}
              <span className="gradient-primary-text">launch</span>
            </h2>
            <p className="mt-4 text-muted-foreground">
              From sign-up to first key in under 5 minutes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {STEPS.map((s, i) => (
              <div
                key={s.n}
                className="relative glass-card rounded-xl p-6"
              >
                <div className="text-5xl font-bold gradient-primary-text opacity-80 mb-3">
                  {s.n}
                </div>
                <h3 className="text-lg font-semibold mb-2">{s.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {s.desc}
                </p>
                {i < STEPS.length - 1 && (
                  <ArrowRight className="hidden lg:block size-5 text-muted-foreground/40 absolute -right-3 top-1/2 -translate-y-1/2" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Code sample */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl sm:text-4xl font-bold mb-6">
              Validate keys{" "}
              <span className="gradient-primary-text">in one line</span>
            </h2>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              Drop the validator into your script. The public endpoint handles
              rate limiting, IP checks, HWID binding, and usage tracking — all
              behind a simple HTTP POST.
            </p>
            <ul className="space-y-3">
              {[
                "Checksum-based format validation (no DB hit)",
                "Automatic expiry & usage-limit enforcement",
                "Per-IP rate limiting (60 req/min by default)",
                "Full audit log of every validation",
              ].map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <div className="mt-0.5 size-5 rounded-full bg-[var(--success)] flex items-center justify-center shrink-0">
                    <Check className="size-3 text-[var(--success-foreground)]" />
                  </div>
                  <span className="text-sm">{item}</span>
                </li>
              ))}
            </ul>
            <div className="mt-8">
              <GradientButton
                variant="primary"
                size="lg"
                onClick={() => openAuth("signup")}
              >
                Get your API key
                <ArrowRight className="size-4" />
              </GradientButton>
            </div>
          </div>

          {/* Code window */}
          <div className="glass-card rounded-xl overflow-hidden">
            <div className="flex items-center gap-2 px-4 py-3 border-b border-border bg-background/40">
              <div className="size-3 rounded-full bg-red-500/80" />
              <div className="size-3 rounded-full bg-yellow-500/80" />
              <div className="size-3 rounded-full bg-green-500/80" />
              <span className="ml-2 text-xs text-muted-foreground font-mono">
                validator.lua
              </span>
            </div>
            <pre className="p-5 text-sm font-mono leading-relaxed overflow-x-auto scrollbar-custom text-slate-300">
{`local http = require("coro-http")

local function validate_key(key, scriptId)
  local res, body = http.request("POST",
    "https://keyvault.app/api/validate",
    { "Content-Type", "application/json" },
    JSON.stringify({ key = key, scriptId = scriptId })
  )
  return JSON.decode(body).valid
end

-- Usage:
if validate_key(userKey, "scr_abc123") then
  print("Access granted")
  -- load the protected script
else
  print("Invalid key — please get a new one at /getkey")
end`}
            </pre>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 pb-24">
        <div className="relative overflow-hidden rounded-2xl glass-card p-8 sm:p-12 text-center">
          <div className="absolute inset-0 bg-grid opacity-30" />
          <div className="relative">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Ready to ship your script?
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto mb-8">
              Join the next generation of script creators using KeyVault to
              monetize their work without infrastructure headaches.
            </p>
            <GradientButton
              variant="primary"
              size="xl"
              onClick={() => openAuth("signup")}
            >
              <Sparkles className="size-4" />
              Create your free account
            </GradientButton>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="size-7 rounded-md bg-primary flex items-center justify-center">
              <Lock className="size-4 text-primary-foreground" />
            </div>
            <span className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} KeyVault — Built on Next.js 16
            </span>
          </div>
          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <button
              onClick={() => setView("validate")}
              className="hover:text-foreground transition-colors"
            >
              Validator
            </button>
            <button
              onClick={() => openAuth("signin")}
              className="hover:text-foreground transition-colors"
            >
              Sign in
            </button>
            <span className="flex items-center gap-1.5">
              <Server className="size-3.5" />
              All systems operational
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
