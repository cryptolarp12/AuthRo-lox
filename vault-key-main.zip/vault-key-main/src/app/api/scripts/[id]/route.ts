import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getAuthUser } from "@/lib/auth";

// GET /api/scripts/[id]
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const script = await db.script.findFirst({
    where: { id, userId: user.id },
    include: {
      keys: {
        orderBy: { createdAt: "desc" },
        take: 10,
      },
      _count: { select: { keys: true } },
    },
  });

  if (!script) {
    return NextResponse.json({ error: "Script not found" }, { status: 404 });
  }

  return NextResponse.json({ script });
}

// PATCH /api/scripts/[id]
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const existing = await db.script.findFirst({
    where: { id, userId: user.id },
  });
  if (!existing) {
    return NextResponse.json({ error: "Script not found" }, { status: 404 });
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const data: any = {};
  if (typeof body.name === "string") data.name = body.name;
  if (typeof body.description === "string") data.description = body.description;
  if (typeof body.language === "string") data.language = body.language;
  if (typeof body.content === "string") data.content = body.content;
  if (typeof body.isPublic === "boolean") data.isPublic = body.isPublic;
  if (typeof body.keyRequired === "boolean") data.keyRequired = body.keyRequired;
  if (typeof body.version === "string") data.version = body.version;

  const updated = await db.script.update({
    where: { id },
    data,
  });

  return NextResponse.json({ script: updated });
}

// DELETE /api/scripts/[id]
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const existing = await db.script.findFirst({
    where: { id, userId: user.id },
  });
  if (!existing) {
    return NextResponse.json({ error: "Script not found" }, { status: 404 });
  }

  // Detach keys (set scriptId null) then delete script
  await db.key.updateMany({
    where: { scriptId: id },
    data: { scriptId: null },
  });
  await db.script.delete({ where: { id } });

  return NextResponse.json({ success: true });
}
