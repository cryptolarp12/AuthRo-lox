"use client";

import { useEffect, useState, useCallback } from "react";
import { useApp } from "@/lib/store";
import { GradientButton } from "./GradientButton";
import { KeyGenModal } from "./KeyGenModal";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Plus,
  Search,
  Copy,
  Check,
  MoreHorizontal,
  Trash2,
  Ban,
  CheckCircle2,
  RefreshCw,
  KeyRound,
  Ticket,
  Download,
  Filter,
} from "./icons";
import { toast } from "sonner";

type KeyItem = {
  id: string;
  key: string;
  status: string;
  computedStatus: string;
  expiresAt: string | null;
  usageLimit: number | null;
  usageCount: number;
  ipRestriction: string | null;
  hardwareId: string | null;
  note: string | null;
  scriptId: string | null;
  script: { id: string; name: string } | null;
  createdAt: string;
  lastUsedAt: string | null;
};

type ScriptOption = { id: string; name: string };

const STATUS_VARIANT: Record<
  string,
  { label: string; className: string; dot: string }
> = {
  ACTIVE: {
    label: "Active",
    className: "bg-green-500/15 text-green-400 border-green-500/30",
    dot: "bg-green-500",
  },
  EXPIRED: {
    label: "Expired",
    className: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30",
    dot: "bg-yellow-500",
  },
  EXHAUSTED: {
    label: "Exhausted",
    className: "bg-orange-500/15 text-orange-400 border-orange-500/30",
    dot: "bg-orange-500",
  },
  REVOKED: {
    label: "Revoked",
    className: "bg-red-500/15 text-red-400 border-red-500/30",
    dot: "bg-red-500",
  },
  PENDING: {
    label: "Pending",
    className: "bg-blue-500/15 text-blue-400 border-blue-500/30",
    dot: "bg-blue-500",
  },
};

export function KeysView() {
  const { setView } = useApp();
  const [keys, setKeys] = useState<KeyItem[]>([]);
  const [scripts, setScripts] = useState<ScriptOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [genOpen, setGenOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [deleteIds, setDeleteIds] = useState<string[]>([]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [keysRes, scriptsRes] = await Promise.all([
        fetch("/api/keys", { cache: "no-store" }),
        fetch("/api/scripts", { cache: "no-store" }),
      ]);
      if (keysRes.ok) {
        const data = await keysRes.json();
        setKeys(data.keys);
      }
      if (scriptsRes.ok) {
        const data = await scriptsRes.json();
        setScripts(data.scripts);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = keys.filter((k) => {
    if (statusFilter !== "ALL" && k.computedStatus !== statusFilter)
      return false;
    if (search) {
      const s = search.toLowerCase();
      if (
        !k.key.toLowerCase().includes(s) &&
        !(k.note || "").toLowerCase().includes(s) &&
        !(k.script?.name || "").toLowerCase().includes(s)
      )
        return false;
    }
    return true;
  });

  const copyKey = (k: KeyItem) => {
    navigator.clipboard.writeText(k.key);
    setCopiedId(k.id);
    toast.success("Key copied to clipboard");
    setTimeout(() => setCopiedId(null), 1500);
  };

  const revokeKey = async (k: KeyItem) => {
    try {
      const res = await fetch(`/api/keys/${k.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "REVOKED" }),
      });
      if (!res.ok) throw new Error("Failed to revoke key");
      toast.success("Key revoked");
      load();
    } catch (e: any) {
      toast.error(e?.message || "Failed to revoke key");
    }
  };

  const reactivateKey = async (k: KeyItem) => {
    try {
      const res = await fetch(`/api/keys/${k.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "ACTIVE" }),
      });
      if (!res.ok) throw new Error("Failed to reactivate key");
      toast.success("Key reactivated");
      load();
    } catch (e: any) {
      toast.error(e?.message || "Failed to reactivate key");
    }
  };

  const deleteKey = async (k: KeyItem) => {
    try {
      const res = await fetch(`/api/keys/${k.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete key");
      toast.success("Key deleted");
      load();
    } catch (e: any) {
      toast.error(e?.message || "Failed to delete key");
    }
  };

  const bulkDelete = async () => {
    if (deleteIds.length === 0) return;
    try {
      const res = await fetch("/api/keys", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: deleteIds }),
      });
      if (!res.ok) throw new Error("Failed to delete keys");
      const data = await res.json();
      toast.success(`Deleted ${data.deleted} key(s)`);
      setDeleteIds([]);
      load();
    } catch (e: any) {
      toast.error(e?.message || "Failed to delete keys");
    }
  };

  const exportCsv = () => {
    const headers = [
      "key",
      "status",
      "script",
      "expiresAt",
      "usageLimit",
      "usageCount",
      "ipRestriction",
      "hardwareId",
      "note",
      "createdAt",
    ];
    const rows = filtered.map((k) =>
      [
        k.key,
        k.computedStatus,
        k.script?.name || "",
        k.expiresAt || "",
        k.usageLimit ?? "",
        k.usageCount,
        k.ipRestriction || "",
        k.hardwareId || "",
        (k.note || "").replace(/,/g, ";"),
        k.createdAt,
      ].join(",")
    );
    const csv = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `keyvault-keys-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${filtered.length} keys to CSV`);
  };

  const toggleSelect = (id: string) => {
    setDeleteIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (deleteIds.length === filtered.length) {
      setDeleteIds([]);
    } else {
      setDeleteIds(filtered.map((k) => k.id));
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">Keys</h1>
          <p className="text-muted-foreground mt-1">
            Generate, manage, and revoke keys.{" "}
            <span className="text-foreground">{keys.length} total</span>
          </p>
        </div>
        <div className="flex items-center gap-2">
          <GradientButton variant="outline" size="default" onClick={load}>
            <RefreshCw className={`size-4 ${loading ? "animate-spin" : ""}`} />
            <span className="hidden sm:inline">Refresh</span>
          </GradientButton>
          <GradientButton
            variant="outline"
            size="default"
            onClick={exportCsv}
            disabled={filtered.length === 0}
          >
            <Download className="size-4" />
            <span className="hidden sm:inline">Export CSV</span>
          </GradientButton>
          <GradientButton
            variant="primary"
            size="default"
            onClick={() => setGenOpen(true)}
          >
            <Plus className="size-4" />
            Generate keys
          </GradientButton>
        </div>
      </div>

      {/* Filters */}
      <Card className="glass-card mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                placeholder="Search by key, note, or script name…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 bg-background border-border"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[180px] bg-background border-border">
                <Filter className="size-4 mr-2 text-muted-foreground" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-card border-border">
                <SelectItem value="ALL">All statuses</SelectItem>
                <SelectItem value="ACTIVE">Active</SelectItem>
                <SelectItem value="EXPIRED">Expired</SelectItem>
                <SelectItem value="EXHAUSTED">Exhausted</SelectItem>
                <SelectItem value="REVOKED">Revoked</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {deleteIds.length > 0 && (
            <div className="mt-4 flex items-center justify-between rounded-lg border border-yellow-500/30 bg-yellow-500/10 px-4 py-2.5">
              <span className="text-sm">
                <span className="font-semibold">{deleteIds.length}</span> key
                {deleteIds.length === 1 ? "" : "s"} selected
              </span>
              <div className="flex items-center gap-2">
                <GradientButton
                  variant="ghost"
                  size="sm"
                  onClick={() => setDeleteIds([])}
                >
                  Cancel
                </GradientButton>
                <GradientButton
                  variant="destructive"
                  size="sm"
                  onClick={bulkDelete}
                >
                  <Trash2 className="size-3.5" />
                  Delete selected
                </GradientButton>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Keys table */}
      <Card className="glass-card">
        <CardContent className="p-0">
          {loading ? (
            <div className="p-8 space-y-3">
              {[0, 1, 2, 3, 4].map((i) => (
                <div key={i} className="h-12 rounded-md shimmer" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <EmptyKeys onGenerate={() => setGenOpen(true)} onGetKey={() => setView("getkey")} />
          ) : (
            <div className="overflow-x-auto scrollbar-custom">
              <Table>
                <TableHeader>
                  <TableRow className="border-border hover:bg-transparent">
                    <TableHead className="w-10">
                      <Switch
                        checked={
                          deleteIds.length === filtered.length &&
                          filtered.length > 0
                        }
                        onCheckedChange={toggleSelectAll}
                        aria-label="Select all"
                      />
                    </TableHead>
                    <TableHead>Key</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Script</TableHead>
                    <TableHead>Usage</TableHead>
                    <TableHead>Expires</TableHead>
                    <TableHead>Last used</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((k) => {
                    const st = STATUS_VARIANT[k.computedStatus] || STATUS_VARIANT.PENDING;
                    const isSelected = deleteIds.includes(k.id);
                    return (
                      <TableRow
                        key={k.id}
                        className={`border-border ${isSelected ? "bg-primary/5" : ""} hover:bg-card/40`}
                      >
                        <TableCell>
                          <Switch
                            checked={isSelected}
                            onCheckedChange={() => toggleSelect(k.id)}
                            aria-label={`Select ${k.key}`}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <code className="text-sm font-mono">
                              {k.key}
                            </code>
                            <button
                              onClick={() => copyKey(k)}
                              className="size-7 rounded-md hover:bg-card flex items-center justify-center transition-colors"
                              title="Copy"
                            >
                              {copiedId === k.id ? (
                                <Check className="size-3.5 text-green-500" />
                              ) : (
                                <Copy className="size-3.5 text-muted-foreground" />
                              )}
                            </button>
                          </div>
                          {k.note && (
                            <div className="text-xs text-muted-foreground mt-0.5 truncate max-w-[240px]">
                              {k.note}
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={`${st.className} border`}
                          >
                            <span
                              className={`size-1.5 rounded-full ${st.dot} mr-1.5`}
                            />
                            {st.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {k.script ? (
                            <span className="text-sm">{k.script.name}</span>
                          ) : (
                            <span className="text-xs text-muted-foreground">
                              Unbound
                            </span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <span className="font-medium">{k.usageCount}</span>
                            {k.usageLimit !== null && (
                              <span className="text-muted-foreground">
                                {" "}
                                / {k.usageLimit}
                              </span>
                            )}
                          </div>
                          {k.usageLimit !== null && k.usageLimit > 0 && (
                            <div className="mt-1 h-1 w-16 rounded-full bg-background overflow-hidden">
                              <div
                                className="h-full gradient-primary rounded-full"
                                style={{
                                  width: `${Math.min(100, (k.usageCount / k.usageLimit) * 100)}%`,
                                }}
                              />
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {k.expiresAt
                            ? new Date(k.expiresAt).toLocaleDateString()
                            : "Never"}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {k.lastUsedAt
                            ? new Date(k.lastUsedAt).toLocaleDateString()
                            : "—"}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <button className="size-8 rounded-md hover:bg-card flex items-center justify-center transition-colors">
                                <MoreHorizontal className="size-4" />
                              </button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent
                              align="end"
                              className="bg-card border-border"
                            >
                              <DropdownMenuItem
                                onClick={() => copyKey(k)}
                              >
                                <Copy className="size-4 mr-2" />
                                Copy key
                              </DropdownMenuItem>
                              {k.computedStatus === "ACTIVE" ? (
                                <DropdownMenuItem
                                  onClick={() => revokeKey(k)}
                                  className="text-yellow-500 focus:text-yellow-500"
                                >
                                  <Ban className="size-4 mr-2" />
                                  Revoke
                                </DropdownMenuItem>
                              ) : k.computedStatus === "REVOKED" ? (
                                <DropdownMenuItem
                                  onClick={() => reactivateKey(k)}
                                  className="text-green-500 focus:text-green-500"
                                >
                                  <CheckCircle2 className="size-4 mr-2" />
                                  Reactivate
                                </DropdownMenuItem>
                              ) : null}
                              <DropdownMenuSeparator className="bg-border" />
                              <DropdownMenuItem
                                onClick={() => deleteKey(k)}
                                className="text-destructive focus:text-destructive"
                              >
                                <Trash2 className="size-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <KeyGenModal
        open={genOpen}
        onClose={() => setGenOpen(false)}
        scripts={scripts}
        onGenerated={() => load()}
      />

      <AlertDialog
        open={deleteIds.length > 0 && false /* bulk delete uses inline UI */}
        onOpenChange={() => {}}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Bulk delete</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={bulkDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function EmptyKeys({
  onGenerate,
  onGetKey,
}: {
  onGenerate: () => void;
  onGetKey: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="size-16 rounded-2xl gradient-primary flex items-center justify-center glow-primary mb-4">
        <KeyRound className="size-8 text-white" />
      </div>
      <h3 className="text-xl font-semibold mb-2">No keys yet</h3>
      <p className="text-muted-foreground mb-6 max-w-md">
        Generate your first batch of keys, or try the /getkey flow to see how
        end-users receive keys after completing an ad-bypass.
      </p>
      <div className="flex gap-2">
        <GradientButton variant="primary" onClick={onGenerate}>
          <Plus className="size-4" />
          Generate keys
        </GradientButton>
        <GradientButton variant="outline" onClick={onGetKey}>
          <Ticket className="size-4" />
          Try /getkey flow
        </GradientButton>
      </div>
    </div>
  );
}
