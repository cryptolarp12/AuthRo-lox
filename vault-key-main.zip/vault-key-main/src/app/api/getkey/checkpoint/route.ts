import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  getRequesterIp,
  checkBlacklist,
  addToBlacklist,
  verifyLootLabsToken,
  isTokenReused,
} from "@/lib/lootlabs";

// Rate limit: max 20 checkpoint attempts per hour per IP
const checkpointAttempts = new Map<string, { count: number; resetAt: number }>();

function rateLimit(ip: string): boolean {
  const now = Date.now();
  const bucket = checkpointAttempts.get(ip);
  if (!bucket || bucket.resetAt < now) {
    checkpointAttempts.set(ip, { count: 1, resetAt: now + 60 * 60 * 1000 });
    return false;
  }
  bucket.count++;
  return bucket.count > 20;
}

/**
 * POST /api/getkey/checkpoint
 *
 * Verifies a checkpoint's completion token. Public endpoint.
 *
 * Body: {
 *   sessionId: string,
 *   checkpointIndex: number,
 *   token: string  (LL_...)
 * }
 *
 * On success: increments checkpointsCompleted on the session.
 * On failure: adds IP to blacklist for 24h.
 */
export async function POST(req: NextRequest) {
  const ip = getRequesterIp(req);

  if (rateLimit(ip)) {
    return NextResponse.json(
      { error: "Too many attempts. Please try again later." },
      { status: 429 }
    );
  }

  // Check blacklist
  const blacklisted = await checkBlacklist({ ip });
  if (blacklisted) {
    const remainingMs = blacklisted.expiresAt.getTime() - Date.now();
    const remainingHours = Math.ceil(remainingMs / (60 * 60 * 1000));
    return NextResponse.json(
      {
        error: `You are blacklisted for ${remainingHours}h`,
        blacklisted: true,
        expiresAt: blacklisted.expiresAt,
      },
      { status: 403 }
    );
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { sessionId, checkpointIndex, token } = body || {};

  if (!sessionId || typeof checkpointIndex !== "number" || !token) {
    await addToBlacklist({ ip, reason: "missing_checkpoint_data" });
    return NextResponse.json(
      { error: "sessionId, checkpointIndex, and token are required" },
      { status: 400 }
    );
  }

  // Load the session
  const session = await db.getKeySession.findUnique({
    where: { id: sessionId },
  });

  if (!session) {
    return NextResponse.json(
      { error: "Session not found" },
      { status: 404 }
    );
  }

  // Check session hasn't expired
  if (session.expiresAt < new Date()) {
    await db.getKeySession.update({
      where: { id: sessionId },
      data: { status: "EXPIRED" },
    });
    return NextResponse.json(
      { error: "Session has expired. Please start a new one." },
      { status: 400 }
    );
  }

  if (session.status !== "IN_PROGRESS") {
    return NextResponse.json(
      { error: `Session is ${session.status}` },
      { status: 400 }
    );
  }

  // Parse checkpoint data
  const checkpoints: any[] = JSON.parse(session.checkpointData);

  // Validate checkpoint index
  if (checkpointIndex < 0 || checkpointIndex >= checkpoints.length) {
    return NextResponse.json(
      { error: "Invalid checkpoint index" },
      { status: 400 }
    );
  }

  // Check checkpoint isn't already completed
  if (checkpoints[checkpointIndex].completed) {
    return NextResponse.json(
      { error: "This checkpoint is already completed" },
      { status: 400 }
    );
  }

  // Checkpoints must be completed in order
  for (let i = 0; i < checkpointIndex; i++) {
    if (!checkpoints[i].completed) {
      return NextResponse.json(
        {
          error: `Complete checkpoint ${i + 1} first`,
        },
        { status: 400 }
      );
    }
  }

  // Check token hasn't been reused (anti-replay)
  if (await isTokenReused(token)) {
    await addToBlacklist({ ip, reason: "reused_token" });
    return NextResponse.json(
      {
        error: "This token has already been used. Blacklisted for 24h.",
        blacklisted: true,
      },
      { status: 400 }
    );
  }

  // Verify the token via LootLabs API
  const linkId = checkpoints[checkpointIndex].linkId;
  const result = await verifyLootLabsToken({ token, linkId });

  if (!result.valid) {
    await addToBlacklist({ ip, reason: "failed_verification" });
    return NextResponse.json(
      {
        error: result.reason || "Verification failed",
        blacklisted: true,
        blacklistedFor: "24h",
      },
      { status: 400 }
    );
  }

  // Mark checkpoint as completed
  checkpoints[checkpointIndex].completed = true;
  checkpoints[checkpointIndex].token = token.slice(0, 6) + "…"; // store partial
  checkpoints[checkpointIndex].verifiedAt = new Date().toISOString();

  const newCompleted = session.checkpointsCompleted + 1;
  const allDone = newCompleted >= session.checkpointsTotal;

  await db.getKeySession.update({
    where: { id: sessionId },
    data: {
      checkpointsCompleted: newCompleted,
      checkpointData: JSON.stringify(checkpoints),
      status: allDone ? "COMPLETED" : "IN_PROGRESS",
    },
  });

  return NextResponse.json({
    success: true,
    checkpointIndex,
    checkpointsCompleted: newCompleted,
    checkpointsTotal: session.checkpointsTotal,
    allDone,
    nextCheckpoint: allDone ? null : checkpointIndex + 1,
  });
}
