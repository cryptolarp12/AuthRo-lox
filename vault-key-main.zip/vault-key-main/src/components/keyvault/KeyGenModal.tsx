"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { GradientButton } from "./GradientButton";
import { Switch } from "@/components/ui/switch";
import { Loader2, KeyRound, Sparkles, Check, Copy } from "./icons";
import { toast } from "sonner";

type GeneratedKey = {
  id: string;
  key: string;
  expiresAt: string | null;
  usageLimit: number | null;
  note: string | null;
  script?: { id: string; name: string } | null;
};

type ScriptOption = { id: string; name: string };

export function KeyGenModal({
  open,
  onClose,
  scripts = [],
  onGenerated,
  defaultScriptId,
}: {
  open: boolean;
  onClose: () => void;
  scripts?: ScriptOption[];
  onGenerated?: (keys: GeneratedKey[]) => void;
  defaultScriptId?: string | null;
}) {
  const [template, setTemplate] = useState("XXXXX-XXXXX-XXXXX-XXXXX");
  const [count, setCount] = useState(1);
  const [expiry, setExpiry] = useState("7d");
  const [usageLimit, setUsageLimit] = useState<number | "">(100);
  const [scriptId, setScriptId] = useState<string>(defaultScriptId || "none");
  const [note, setNote] = useState("");
  const [ipRestriction, setIpRestriction] = useState("");
  const [hardwareId, setHardwareId] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [generated, setGenerated] = useState<GeneratedKey[]>([]);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const handleGenerate = async () => {
    setSubmitting(true);
    try {
      const res = await fetch("/api/keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          template,
          count,
          expiresAt: expiry || null,
          usageLimit: typeof usageLimit === "number" ? usageLimit : null,
          scriptId: scriptId === "none" ? null : scriptId,
          note: note || null,
          ipRestriction: ipRestriction || null,
          hardwareId: hardwareId || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Failed to generate keys");
        return;
      }
      setGenerated(data.keys);
      toast.success(`Generated ${data.count} key${data.count === 1 ? "" : "s"}`);
      onGenerated?.(data.keys);
    } catch (e: any) {
      toast.error(e?.message || "Network error");
    } finally {
      setSubmitting(false);
    }
  };

  const reset = () => {
    setGenerated([]);
    setTemplate("XXXXX-XXXXX-XXXXX-XXXXX");
    setCount(1);
    setExpiry("7d");
    setUsageLimit(100);
    setScriptId(defaultScriptId || "none");
    setNote("");
    setIpRestriction("");
    setHardwareId("");
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const copyKey = (key: string, idx: number) => {
    navigator.clipboard.writeText(key);
    setCopiedIdx(idx);
    toast.success("Key copied");
    setTimeout(() => setCopiedIdx(null), 1500);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent className="sm:max-w-lg bg-card border-border text-foreground max-h-[90vh] overflow-y-auto scrollbar-custom">
        <DialogHeader>
          <div className="mx-auto mb-3 size-12 rounded-xl gradient-primary flex items-center justify-center glow-primary">
            <KeyRound className="size-6 text-white" />
          </div>
          <DialogTitle className="text-center text-xl">
            {generated.length > 0
              ? "Keys generated!"
              : "Generate new keys"}
          </DialogTitle>
          <DialogDescription className="text-center">
            {generated.length > 0
              ? `${generated.length} key${generated.length === 1 ? "" : "s"} ready to use`
              : "Configure the key template and constraints"}
          </DialogDescription>
        </DialogHeader>

        {generated.length > 0 ? (
          <div className="space-y-3 py-2">
            {generated.map((k, idx) => (
              <div
                key={k.id}
                className="rounded-lg border border-border bg-background/50 p-3"
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <code className="text-sm font-mono gradient-primary-text font-semibold break-all">
                    {k.key}
                  </code>
                  <button
                    onClick={() => copyKey(k.key, idx)}
                    className="size-8 rounded-md hover:bg-card flex items-center justify-center transition-colors shrink-0"
                    title="Copy key"
                  >
                    {copiedIdx === idx ? (
                      <Check className="size-4 text-green-500" />
                    ) : (
                      <Copy className="size-4 text-muted-foreground" />
                    )}
                  </button>
                </div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                  {k.script && (
                    <span className="px-2 py-0.5 rounded bg-secondary/60">
                      {k.script.name}
                    </span>
                  )}
                  {k.expiresAt && (
                    <span>
                      Expires:{" "}
                      {new Date(k.expiresAt).toLocaleDateString()}
                    </span>
                  )}
                  {k.usageLimit !== null && (
                    <span>Limit: {k.usageLimit}</span>
                  )}
                </div>
              </div>
            ))}
            <div className="flex gap-2 pt-2">
              <GradientButton
                variant="primary"
                className="flex-1"
                onClick={reset}
              >
                <Sparkles className="size-4" />
                Generate more
              </GradientButton>
              <GradientButton
                variant="outline"
                className="flex-1"
                onClick={handleClose}
              >
                Done
              </GradientButton>
            </div>
          </div>
        ) : (
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="template">Key template</Label>
              <Input
                id="template"
                value={template}
                onChange={(e) =>
                  setTemplate(e.target.value.toUpperCase())
                }
                placeholder="XXXXX-XXXXX-XXXXX-XXXXX"
                className="font-mono bg-background border-border"
              />
              <p className="text-xs text-muted-foreground">
                Use <code className="text-primary">X</code> for random
                characters. A checksum digit is appended automatically.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="count">How many keys</Label>
                <Input
                  id="count"
                  type="number"
                  min={1}
                  max={50}
                  value={count}
                  onChange={(e) =>
                    setCount(
                      Math.max(1, Math.min(50, Number(e.target.value) || 1))
                    )
                  }
                  className="bg-background border-border"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="expiry">Expires after</Label>
                <Select value={expiry} onValueChange={setExpiry}>
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="1h">1 hour</SelectItem>
                    <SelectItem value="24h">24 hours</SelectItem>
                    <SelectItem value="7d">7 days</SelectItem>
                    <SelectItem value="30d">30 days</SelectItem>
                    <SelectItem value="90d">90 days</SelectItem>
                    <SelectItem value="never">Never</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="usage">Usage limit (optional)</Label>
                <Input
                  id="usage"
                  type="number"
                  min={0}
                  value={usageLimit}
                  onChange={(e) =>
                    setUsageLimit(
                      e.target.value === ""
                        ? ""
                        : Math.max(0, Number(e.target.value))
                    )
                  }
                  placeholder="unlimited"
                  className="bg-background border-border"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="script">Bind to script (optional)</Label>
                <Select value={scriptId} onValueChange={setScriptId}>
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="none">No script</SelectItem>
                    {scripts.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="note">Note (optional)</Label>
              <Textarea
                id="note"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Internal note for this batch"
                className="bg-background border-border min-h-[60px]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="ip">IP restriction (optional)</Label>
                <Input
                  id="ip"
                  value={ipRestriction}
                  onChange={(e) => setIpRestriction(e.target.value)}
                  placeholder="192.168.1.0/24"
                  className="bg-background border-border font-mono text-xs"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hwid">Hardware ID (optional)</Label>
                <Input
                  id="hwid"
                  value={hardwareId}
                  onChange={(e) => setHardwareId(e.target.value)}
                  placeholder="auto-bind on first use"
                  className="bg-background border-border font-mono text-xs"
                />
              </div>
            </div>

            <GradientButton
              variant="primary"
              size="lg"
              className="w-full"
              onClick={handleGenerate}
              disabled={submitting}
            >
              {submitting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Sparkles className="size-4" />
              )}
              Generate {count > 1 ? `${count} keys` : "key"}
            </GradientButton>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
