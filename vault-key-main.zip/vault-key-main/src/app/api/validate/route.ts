import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { keyStatus, validateKeyFormat } from "@/lib/keys";
import { limiters } from "@/lib/rate-limit";

/**
 * POST /api/validate
 * Public endpoint used by client scripts to validate a key at runtime.
 *
 * Body: { key: string, scriptId?: string, ip?: string, hardwareId?: string }
 * Returns: { valid: boolean, status, expiresAt?, usageLimit?, usageCount?, script? }
 */
export async function POST(req: NextRequest) {
  const limited = limiters.validate(req);
  if (limited) return limited;

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { key, scriptId, ip, hardwareId } = body || {};
  if (!key || typeof key !== "string") {
    return NextResponse.json(
      { valid: false, error: "Key is required" },
      { status: 400 }
    );
  }

  // First: format check (cheap)
  if (!validateKeyFormat(key)) {
    return NextResponse.json({
      valid: false,
      status: "INVALID_FORMAT",
      message: "Key format is invalid (failed checksum)",
    });
  }

  const found = await db.key.findUnique({
    where: { key },
    include: { script: true },
  });

  if (!found) {
    return NextResponse.json({
      valid: false,
      status: "NOT_FOUND",
      message: "Key does not exist",
    });
  }

  // Compute status
  const computedStatus = keyStatus(found);

  // IP restriction check
  if (found.ipRestriction && ip && !ipMatches(ip, found.ipRestriction)) {
    return NextResponse.json({
      valid: false,
      status: "IP_BLOCKED",
      message: "Key is restricted to a different IP",
    });
  }

  // Hardware ID check
  if (found.hardwareId && hardwareId && hardwareId !== found.hardwareId) {
    return NextResponse.json({
      valid: false,
      status: "HWID_MISMATCH",
      message: "Key is bound to a different hardware ID",
    });
  }

  // Script binding check
  if (scriptId && found.scriptId && found.scriptId !== scriptId) {
    return NextResponse.json({
      valid: false,
      status: "SCRIPT_MISMATCH",
      message: "Key is not authorized for this script",
    });
  }

  if (computedStatus !== "ACTIVE") {
    return NextResponse.json({
      valid: false,
      status: computedStatus,
      message: `Key is ${computedStatus.toLowerCase()}`,
    });
  }

  // Increment usage count + update lastUsedAt
  await db.key.update({
    where: { id: found.id },
    data: {
      usageCount: { increment: 1 },
      lastUsedAt: new Date(),
    },
  });

  return NextResponse.json({
    valid: true,
    status: "ACTIVE",
    key: {
      id: found.id,
      expiresAt: found.expiresAt,
      usageLimit: found.usageLimit,
      usageCount: found.usageCount + 1,
    },
    script: found.script
      ? {
          id: found.script.id,
          name: found.script.name,
          version: found.script.version,
        }
      : null,
  });
}

function ipMatches(ip: string, pattern: string): boolean {
  if (pattern === ip) return true;
  // CIDR-lite: support prefix match like "192.168."
  if (pattern.endsWith(".")) {
    return ip.startsWith(pattern);
  }
  // Wildcard
  if (pattern.includes("*")) {
    const re = new RegExp(
      "^" + pattern.replace(/\./g, "\\.").replace(/\*/g, ".*") + "$"
    );
    return re.test(ip);
  }
  return false;
}
