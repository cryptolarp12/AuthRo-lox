import { db } from "@/lib/db";
import { auth, currentUser } from "@clerk/nextjs/server";

export type AuthUser = {
  id: string; // our DB user id
  clerkId: string;
  email: string;
  username: string | null;
  avatar: string | null;
};

/**
 * Returns the authenticated user, looking them up in our DB by Clerk ID.
 * If the Clerk user exists but not yet in our DB (webhook hasn't fired yet),
 * we lazily create a record — this is a fallback, not the primary path.
 */
export async function getAuthUser(): Promise<AuthUser | null> {
  const clerk = await auth();
  if (!clerk.userId) return null;

  // Look up by Clerk ID
  let dbUser = await db.user.findUnique({
    where: { clerkId: clerk.userId },
  });

  // Lazy-create if missing (e.g., webhook didn't fire yet)
  if (!dbUser) {
    const user = await currentUser();
    if (!user) return null;

    const email =
      user.emailAddresses?.[0]?.emailAddress ||
      user.primaryEmailAddress?.emailAddress ||
      "";

    if (!email) return null;

    const username =
      user.username ||
      `${user.firstName || ""} ${user.lastName || ""}`.trim() ||
      email.split("@")[0] ||
      "user";

    try {
      dbUser = await db.user.create({
        data: {
          clerkId: user.id,
          email,
          username,
          avatar: user.imageUrl || null,
        },
      });
    } catch (e) {
      // Race with webhook — try to fetch again
      dbUser = await db.user.findUnique({
        where: { clerkId: clerk.userId },
      });
      if (!dbUser) return null;
    }
  }

  return {
    id: dbUser.id,
    clerkId: dbUser.clerkId,
    email: dbUser.email,
    username: dbUser.username,
    avatar: dbUser.avatar && !dbUser.avatar.startsWith("{") ? dbUser.avatar : null,
  };
}

/**
 * Server-side helper: requires an authenticated user, throws 401 otherwise.
 * Returns the AuthUser.
 */
export async function requireAuth(): Promise<AuthUser> {
  const user = await getAuthUser();
  if (!user) {
    const err = new Error("UNAUTHORIZED");
    (err as any).statusCode = 401;
    throw err;
  }
  return user;
}
