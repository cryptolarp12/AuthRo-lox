"use client";

import { create } from "zustand";
import { useUser as useClerkUser, useClerk } from "@clerk/nextjs";
import { useEffect } from "react";

export type AuthUser = {
  id: string;
  clerkId: string;
  email: string;
  username: string | null;
  avatar: string | null;
};

type AuthState = {
  user: AuthUser | null;
  loading: boolean;
  refresh: () => Promise<void>;
  signOut: () => Promise<void>;
  setUser: (u: AuthUser | null) => void;
  setLoading: (b: boolean) => void;
};

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  refresh: async () => {
    try {
      const res = await fetch("/api/me", { cache: "no-store" });
      const data = await res.json();
      set({ user: data.user || null, loading: false });
    } catch {
      set({ user: null, loading: false });
    }
  },
  signOut: async () => {
    // Sign-out is handled by Clerk's useClerk().signOut() in the hook below
    set({ user: null });
  },
  setUser: (u) => set({ user: u }),
  setLoading: (b) => set({ loading: b }),
}));

/**
 * Unified auth hook that bridges Clerk's session with our DB-backed user.
 *
 * - `user` comes from our DB (via /api/me), which uses Clerk's auth()
 * - `loading` reflects whether we're still resolving the session
 * - `signOut()` delegates to Clerk
 * - `openSignIn()` / `openSignUp()` redirect to the Clerk-hosted pages
 */
export function useAuth() {
  const { user: clerkUser, isLoaded } = useClerkUser();
  const clerk = useClerk();
  const { user, loading, refresh, setUser, setLoading } = useAuthStore();

  // Whenever Clerk's session changes, re-fetch our DB user
  useEffect(() => {
    if (!isLoaded) return;
    if (clerkUser) {
      refresh();
    } else {
      setUser(null);
      setLoading(false);
    }
  }, [isLoaded, clerkUser?.id, refresh, setUser, setLoading]);

  return {
    user,
    loading: !isLoaded || loading,
    refresh,
    signOut: () => clerk.signOut(({ redirectTo: "/" }) as any),
    openSignIn: () => clerk.redirectToSignIn(),
    openSignUp: () => clerk.redirectToSignUp(),
  };
}

export function useAuthBootstrap() {
  // No-op — Clerk handles bootstrap via ClerkProvider
}
