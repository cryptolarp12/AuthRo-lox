import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getAuthUser } from "@/lib/auth";

// GET /api/scripts
export async function GET() {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const scripts = await db.script.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: "desc" },
    include: {
      _count: { select: { keys: true } },
    },
  });

  return NextResponse.json({ scripts });
}

// POST /api/scripts — create a new script
export async function POST(req: NextRequest) {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { name, description, language, content, isPublic, keyRequired } = body || {};
  if (!name || typeof name !== "string" || name.trim().length === 0) {
    return NextResponse.json({ error: "Name is required" }, { status: 400 });
  }

  const script = await db.script.create({
    data: {
      name: name.trim(),
      description: description || null,
      language: language || "lua",
      content: content || "",
      isPublic: Boolean(isPublic),
      keyRequired: keyRequired === false ? false : true,
      userId: user.id,
      version: "1.0.0",
    },
  });

  return NextResponse.json({ script });
}
