import { db } from "@/lib/db";
import { notFound } from "next/navigation";
import { GetKeyPublicFlow } from "@/components/keyvault/GetKeyPublicFlow";

export const dynamic = "force-dynamic";

interface PageProps {
  params: Promise<{ scriptId: string }>;
}

export default async function GetKeyScriptPage({ params }: PageProps) {
  const { scriptId } = await params;

  const script = await db.script.findFirst({
    where: { id: scriptId },
    select: {
      id: true,
      name: true,
      description: true,
      language: true,
      version: true,
      isPublic: true,
      keyRequired: true,
      content: true,
      user: {
        select: { username: true, email: true },
      },
    },
  });

  if (!script) {
    notFound();
  }

  // If the script is private, don't show the public getkey page
  if (!script.isPublic) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <h1 className="text-2xl font-bold mb-2">Script not available</h1>
          <p className="text-muted-foreground">
            This script is private and doesn&apos;t have a public key system.
          </p>
        </div>
      </div>
    );
  }

  return <GetKeyPublicFlow script={script} />;
}
