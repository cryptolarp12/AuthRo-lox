"use client";

import { useState } from "react";
import { useApp } from "@/lib/store";
import { useAuth } from "@/hooks/use-auth";
import { GradientButton } from "./GradientButton";
import { UserButton } from "@clerk/nextjs";
import { ThemeToggle } from "./ThemeToggle";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
  SheetHeader,
} from "@/components/ui/sheet";
import {
  LayoutDashboard,
  KeyRound,
  FileCode2,
  Ticket,
  ShieldCheck,
  LogOut,
  Menu,
  KeyVaultLogo,
} from "./icons";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const NAV_ITEMS = [
  { view: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { view: "keys", label: "Keys", icon: KeyRound },
  { view: "scripts", label: "Scripts", icon: FileCode2 },
  { view: "validate", label: "Validator", icon: ShieldCheck },
] as const;

export function Navbar() {
  const { view, setView } = useApp();
  const { user, loading, openSignUp, openSignIn } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNav = (v: typeof view) => {
    setView(v);
    setMobileOpen(false);
  };

  const handleSignOut = async () => {
    // Clerk's UserButton handles sign-out natively; this is a fallback
    // for the mobile Sheet's sign-out button.
    window.location.href = "/sign-in";
  };

  return (
    <header className="glass-nav sticky top-0 z-40">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        {/* Logo */}
        <button
          onClick={() => setView(user ? "dashboard" : "landing")}
          className="flex items-center gap-2 group"
        >
          <div className="size-9 rounded-lg bg-primary flex items-center justify-center group-hover:scale-105 transition-transform">
            <KeyVaultLogo className="size-5 text-primary-foreground" />
          </div>
          <span className="text-lg font-bold tracking-tight">
            Key<span className="gradient-primary-text">Vault</span>
          </span>
        </button>

        {/* Desktop nav (only when authed) */}
        {user && (
          <nav className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = view === item.view;
              return (
                <button
                  key={item.view}
                  onClick={() => handleNav(item.view)}
                  className={cn(
                    "relative flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-colors",
                    active
                      ? "text-foreground gradient-border-active"
                      : "text-muted-foreground hover:text-foreground hover:bg-card/50"
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        )}

        {/* Right side: auth actions */}
        <div className="flex items-center gap-2">
          {loading ? (
            <div className="h-9 w-20 rounded-md shimmer" />
          ) : user ? (
            <>
              <ThemeToggle />
              {/* Clerk's UserButton — handles avatar, profile, sign-out */}
              <div className="flex items-center gap-2">
                <span className="hidden sm:block text-sm font-medium max-w-[140px] truncate">
                  {user.username || user.email}
                </span>
                <UserButton
                  afterSignOutUrl="/"
                  appearance={{
                    elements: {
                      avatarBox: "size-9 border border-border",
                    },
                  }}
                />
              </div>

              {/* Mobile menu trigger */}
              <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
                <SheetTrigger asChild>
                  <button className="md:hidden inline-flex items-center justify-center size-9 rounded-md hover:bg-card/60">
                    <Menu className="size-5" />
                  </button>
                </SheetTrigger>
                <SheetContent
                  side="right"
                  className="w-72 bg-card border-border"
                >
                  <SheetHeader>
                    <SheetTitle className="flex items-center gap-2">
                      <div className="size-7 rounded-md bg-primary flex items-center justify-center">
                        <KeyVaultLogo className="size-4 text-primary-foreground" />
                      </div>
                      KeyVault
                    </SheetTitle>
                  </SheetHeader>
                  <nav className="mt-6 flex flex-col gap-1">
                    {NAV_ITEMS.map((item) => {
                      const Icon = item.icon;
                      const active = view === item.view;
                      return (
                        <button
                          key={item.view}
                          onClick={() => handleNav(item.view)}
                          className={cn(
                            "flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-md transition-colors",
                            active
                              ? "gradient-primary text-white"
                              : "text-muted-foreground hover:text-foreground hover:bg-background/60"
                          )}
                        >
                          <Icon className="size-4" />
                          {item.label}
                        </button>
                      );
                    })}
                    <div className="my-2 border-t border-border" />
                    <a
                      href="/sign-in"
                      className="flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-md text-destructive hover:bg-destructive/10 transition-colors"
                    >
                      <LogOut className="size-4" />
                      Sign out
                    </a>
                  </nav>
                </SheetContent>
              </Sheet>
            </>
          ) : (
            <>
              <ThemeToggle />
              <a
                href="/getkey"
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
              >
                <Ticket className="size-3.5" />
                Get a Key
              </a>
              <GradientButton
                variant="ghost"
                size="sm"
                onClick={() => openSignIn()}
                className="hidden sm:inline-flex"
              >
                Sign in
              </GradientButton>
              <GradientButton
                variant="primary"
                size="sm"
                onClick={() => openSignUp()}
              >
                Get Started
              </GradientButton>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
