# KeyVault — Modern Key System Service

A production-style key management service with public `/getkey/[scriptId]` checkpoint flow, Clerk auth, Supabase database, and a smooth light/dark theme.

## What's New

### Public `/getkey/[scriptId]` Page (No Auth Required)
- Each script gets its own public key-system page at `/getkey/[scriptId]`
- Users pick a duration: **12 hours (1 ad)** or **24 hours (2 ads)**
- Checkpoint loader shows progress (1/2, 2/2, etc.)
- Each checkpoint has a "Go to LootLabs Ad" button that opens a dynamically-created ad link
- After completing the ad, user pastes their `LL_...` completion token
- Token is verified via LootLabs API → checkpoint marked complete
- When all checkpoints done → "Generate My Key" button appears
- Key is created with the chosen expiry (12h or 24h)

### Per-Script Key/Keyless Toggle
- In the Scripts dashboard, every script has a "Require a key" toggle
- **Key required** (default): users must complete the /getkey ad flow
- **Keyless**: `/getkey/[scriptId]` shows the script content directly, no key needed
- Toggle is available in both the create modal and the editor sidebar

### Anti-Bypass System
- Every checkpoint token is verified via the LootLabs API (`LOOTLABS_API_KEY`)
- Tokens can't be reused (anti-replay check across all sessions)
- Checkpoints must be completed in order
- "Generate Key" button only appears after all checkpoints are verified
- Calling `/api/getkey/generate` without completing checkpoints → 24h blacklist
- Failed token verification → 24h blacklist for the IP
- Blacklist is checked on every API call

### LootLabs API Integration
- Ad links are created dynamically via `POST https://api.lootlabs.io/v1/link/create`
- Each checkpoint gets its own unique ad URL
- The destination URL is set to `/getkey/[scriptId]` (so users return after completing)
- Token verification via `POST https://api.lootlabs.io/v1/verify_completion`
- If the API is unreachable, falls back to format-check (`LL_` prefix, ≥16 chars)

### Supabase Database
- PostgreSQL hosted on Supabase
- Uses Prisma ORM with two connection strings:
  - `DATABASE_URL` — transaction pooler (port 6543) for app runtime
  - `DIRECT_URL` — session pooler (port 5432) for migrations
- Client-side Supabase SDK available for direct queries if needed

## Tech Stack
- Next.js 16 (App Router) + React 19 + TypeScript 5
- Clerk authentication (for creators/dashboard only — /getkey is public)
- Prisma ORM + Supabase PostgreSQL
- Tailwind CSS 4 + shadcn/ui
- next-themes (light + dark)
- Lucide icons

## Public vs Protected Routes

**Public (no auth):**
- `/` — Landing page
- `/getkey` — Lists all public scripts with key systems
- `/getkey/[scriptId]` — The checkpoint flow for a specific script
- `/sign-in`, `/sign-up` — Clerk hosted pages
- `POST /api/validate` — Key validation (used by client scripts)
- `POST /api/getkey/start` — Start a /getkey session
- `POST /api/getkey/checkpoint` — Verify a checkpoint token
- `POST /api/getkey/generate` — Generate the final key
- `GET /api/getkey/status` — Check session status

**Protected (Clerk auth):**
- `/api/me`, `/api/keys/*`, `/api/scripts/*`, `/api/stats` — Dashboard APIs

## Setup

### 1. Install dependencies
```bash
bun install
```

### 2. Configure environment variables
Copy `.env.example` to `.env` and fill in real values:
```bash
cp .env.example .env
```

Key variables:
- `DATABASE_URL` + `DIRECT_URL` — Supabase PostgreSQL connection strings
- `NEXT_PUBLIC_SUPABASE_URL` + `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` — Supabase client
- `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` + `CLERK_SECRET_KEY` — Clerk auth
- `LOOTLABS_API_KEY` — for ad-link creation + token verification
- `NEXT_PUBLIC_APP_URL` — where LootLabs redirects back to

### 3. Create database tables
```bash
bun run db:push
```

### 4. Run dev server
```bash
bun run dev
```

## Environment Variables

See `.env.example` for the full list with descriptions.

## API Endpoints

### Public
| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/validate` | Validate a key (used by client scripts) |
| `POST` | `/api/getkey/start` | Start a /getkey session — returns checkpoint URLs |
| `POST` | `/api/getkey/checkpoint` | Verify a checkpoint's completion token |
| `POST` | `/api/getkey/generate` | Generate the final key after all checkpoints |
| `GET` | `/api/getkey/status` | Check session status |
| `POST` | `/api/clerk/webhook` | Clerk user sync webhook |

### Protected (Clerk)
| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/me` | Get current user |
| `GET/POST` | `/api/keys` | List / generate keys |
| `GET/PATCH/DELETE` | `/api/keys/[id]` | Key CRUD |
| `GET/POST` | `/api/scripts` | List / create scripts (supports `keyRequired`) |
| `GET/PATCH/DELETE` | `/api/scripts/[id]` | Script CRUD |
| `GET` | `/api/stats` | Dashboard stats |

## The /getkey Flow

```
User visits /getkey/[scriptId]
       │
       ▼
  Script exists & is public?
       │
       ├── No ──► 404 / "not available"
       │
       ▼
  keyRequired = false? ──► Show "No key required" + copy script
       │
       Yes
       ▼
  Step 1: Choose duration
  ┌────────────┐  ┌────────────┐
  │  12 hours   │  │  24 hours   │
  │  1 ad       │  │  2 ads      │
  └────────────┘  └────────────┘
       │
       ▼
  POST /api/getkey/start { scriptId, durationHours }
       │
       ▼
  Server creates GetKeySession
  Server calls LootLabs API to create ad links
  Returns: { sessionId, checkpoints: [{ url, linkId }] }
       │
       ▼
  Step 2: Checkpoint flow
  ┌──────────────────────────────────┐
  │  Progress: 0/2                    │
  │  ● ─── ○ ─── ○                   │
  │                                   │
  │  Checkpoint 1:                    │
  │  [ Go to LootLabs Ad #1 → ]      │
  │  Token: [ LL_xxxxxxxxxxxx ]      │
  │  [ Verify checkpoint ]            │
  │                                   │
  │  Checkpoint 2: (locked)           │
  └──────────────────────────────────┘
       │
       ▼
  User clicks "Go to LootLabs Ad"
  → Opens ad URL in new tab
  → Completes the ad on lootlabs.io
  → Receives completion token (LL_...)
       │
       ▼
  User pastes token → POST /api/getkey/checkpoint
       │
       ├── Check blacklist (24h block)
       ├── Check token not reused
       ├── Verify via LootLabs API
       │
       ├── Invalid ──► Blacklist IP for 24h
       │
       ▼
  Valid! Mark checkpoint complete
  If all done → status = COMPLETED
       │
       ▼
  Step 3: Generate key
  [ 🔑 Generate My Key ]
       │
       ▼
  POST /api/getkey/generate { sessionId }
       │
       ├── Verify session status = COMPLETED (anti-bypass)
       ├── Verify session not expired
       │
       ▼
  Create Key (userId = null, scriptId = bound, expiresAt = now + durationHours)
       │
       ▼
  Display key to user
```

## How to Deploy to Vercel

1. Push to GitHub
2. Go to https://vercel.com/new
3. Import the repository
4. Add all environment variables from `.env.example`
5. Deploy
6. After deployment:
   - Update `NEXT_PUBLIC_APP_URL` to your Vercel URL
   - In Clerk dashboard → **Domains** → add your Vercel URL
   - In Clerk dashboard → **Webhooks** → add `https://your-vercel-url/api/clerk/webhook`
   - Copy the `whsec_...` signing secret → set as `CLERK_WEBHOOK_SECRET`

## How to Get Cloudflare Turnstile Keys

Clerk already uses Turnstile internally. To get your own keys for custom forms:

1. Go to https://dash.cloudflare.com/?to=/:account/turnstile
2. Click **Add Site**
3. Fill in:
   - Site name: `KeyVault`
   - Domain: your Vercel URL
   - Widget mode: **Managed**
4. Click **Create**
5. Copy both keys:
   - Site Key (`0x4AAAA...`) → `NEXT_PUBLIC_TURNSTILE_SITE_KEY`
   - Secret Key (`0x4AAAA...`) → `TURNSTILE_SECRET_KEY`
