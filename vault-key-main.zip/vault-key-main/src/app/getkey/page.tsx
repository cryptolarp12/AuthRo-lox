import { db } from "@/lib/db";
import Link from "next/link";
import { KeyRound, FileCode2, ArrowRight, Globe } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function GetKeyListPage() {
  const scripts = await db.script.findMany({
    where: {
      isPublic: true,
      keyRequired: true,
    },
    select: {
      id: true,
      name: true,
      description: true,
      language: true,
      version: true,
      createdAt: true,
      user: { select: { username: true, email: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="glass-nav sticky top-0 z-40">
        <div className="mx-auto flex h-14 max-w-3xl items-center justify-between px-4">
          <a href="/" className="flex items-center gap-2">
            <div className="size-7 rounded-md bg-primary flex items-center justify-center">
              <KeyRound className="size-4 text-primary-foreground" />
            </div>
            <span className="text-sm font-bold tracking-tight">
              Key<span className="text-primary-hue">Vault</span>
            </span>
          </a>
          <a
            href="/sign-in"
            className="text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            Creator login →
          </a>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 sm:px-6 py-10">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Get a key</h1>
          <p className="text-muted-foreground">
            Pick a script below to start the /getkey flow. Complete the ad
            checkpoints to receive your key.
          </p>
        </div>

        {scripts.length === 0 ? (
          <div className="text-center py-16">
            <div className="size-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
              <FileCode2 className="size-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-semibold mb-2">No scripts yet</h2>
            <p className="text-muted-foreground text-sm">
              No public scripts with key systems have been published yet.
            </p>
          </div>
        ) : (
          <div className="grid gap-3">
            {scripts.map((s) => (
              <Link
                key={s.id}
                href={`/getkey/${s.id}`}
                className="group glass-card rounded-xl p-5 hover:border-primary/40 transition-all hover:-translate-y-0.5 block"
              >
                <div className="flex items-start gap-3">
                  <div className="size-10 rounded-lg bg-primary-soft flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                    <FileCode2 className="size-5 text-primary-hue" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold truncate">{s.name}</h3>
                      <span className="text-xs px-2 py-0.5 rounded bg-muted/60 font-mono">
                        {s.language}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-1">
                      {s.description || "No description"}
                    </p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Globe className="size-3" />
                        Public
                      </span>
                      {s.user && (
                        <span>by {s.user.username || s.user.email}</span>
                      )}
                      <span>v{s.version}</span>
                    </div>
                  </div>
                  <ArrowRight className="size-4 text-muted-foreground group-hover:text-foreground transition-colors shrink-0 mt-1" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
