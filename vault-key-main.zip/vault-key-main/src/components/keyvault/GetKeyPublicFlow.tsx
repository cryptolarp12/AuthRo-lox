"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { GradientButton } from "./GradientButton";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import {
  Ticket,
  Loader2,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Copy,
  Check,
  Clock,
  KeyRound,
  ExternalLink,
  Ban,
  Activity,
  Lock,
  Zap,
  ArrowRight,
} from "./icons";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

type Script = {
  id: string;
  name: string;
  description: string | null;
  language: string;
  version: string;
  isPublic: boolean;
  keyRequired: boolean;
  content: string;
  user: { username: string | null; email: string } | null;
};

type Checkpoint = {
  index: number;
  url: string;
  linkId: string;
  fallback: boolean;
  completed: boolean;
  token: string | null;
  verifiedAt?: string;
};

type Session = {
  sessionId: string;
  durationHours: number;
  checkpointsTotal: number;
  checkpointsCompleted: number;
  checkpoints: Checkpoint[];
  expiresAt: string;
};

type Step = "duration" | "checkpoints" | "generating" | "success" | "error";

export function GetKeyPublicFlow({ script }: { script: Script }) {
  const [step, setStep] = useState<Step>("duration");
  const [duration, setDuration] = useState<12 | 24>(12);
  const [session, setSession] = useState<Session | null>(null);
  const [tokenInputs, setTokenInputs] = useState<string[]>([]);
  const [submittingCheckpoint, setSubmittingCheckpoint] = useState<number | null>(null);
  const [starting, setStarting] = useState(false);
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const [keyExpiresAt, setKeyExpiresAt] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [blackout, setBlackout] = useState<{ expiresAt: string; reason: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Cleanup polling on unmount
  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  // If script is keyless, show a different UI
  if (!script.keyRequired) {
    return <KeylessScriptView script={script} />;
  }

  const startSession = async () => {
    setStarting(true);
    setError(null);
    try {
      const res = await fetch("/api/getkey/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scriptId: script.id,
          durationHours: duration,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.blacklisted) {
          setBlackout({
            expiresAt: data.expiresAt,
            reason: data.reason || "blacklisted",
          });
          setStep("error");
        } else {
          setError(data.error || "Failed to start session");
          toast.error(data.error || "Failed to start session");
        }
        return;
      }
      setSession(data);
      setTokenInputs(new Array(data.checkpointsTotal).fill(""));
      setStep("checkpoints");
      toast.success(`${data.checkpointsTotal} checkpoint${data.checkpointsTotal > 1 ? "s" : ""} to complete`);
    } catch (e: any) {
      setError(e?.message || "Network error");
      toast.error(e?.message || "Network error");
    } finally {
      setStarting(false);
    }
  };

  const verifyCheckpoint = async (index: number) => {
    const token = tokenInputs[index]?.trim();
    if (!token) {
      toast.error("Paste your completion token first");
      return;
    }
    setSubmittingCheckpoint(index);
    try {
      const res = await fetch("/api/getkey/checkpoint", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId: session!.sessionId,
          checkpointIndex: index,
          token,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.blacklisted) {
          setBlackout({
            expiresAt: data.expiresAt || new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
            reason: "bypass_attempt",
          });
          setStep("error");
        } else {
          toast.error(data.error || "Verification failed");
        }
        return;
      }
      // Update local state
      const updatedCheckpoints = session!.checkpoints.map((cp, i) =>
        i === index
          ? { ...cp, completed: true, token: token.slice(0, 6) + "…", verifiedAt: new Date().toISOString() }
          : cp
      );
      const updatedSession = {
        ...session!,
        checkpointsCompleted: data.checkpointsCompleted,
        checkpoints: updatedCheckpoints,
      };
      setSession(updatedSession);

      if (data.allDone) {
        toast.success("All checkpoints complete! Generating your key…");
        // Auto-advance to key generation
        setTimeout(() => generateKey(updatedSession.sessionId), 800);
      } else {
        toast.success(`Checkpoint ${index + 1} verified!`);
      }
    } catch (e: any) {
      toast.error(e?.message || "Network error");
    } finally {
      setSubmittingCheckpoint(null);
    }
  };

  const generateKey = async (sessionId: string) => {
    setStep("generating");
    try {
      const res = await fetch("/api/getkey/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.blacklisted) {
          setBlackout({
            expiresAt: data.expiresAt || new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
            reason: "bypass_attempt",
          });
          setStep("error");
        } else {
          setError(data.error || "Failed to generate key");
          setStep("error");
        }
        return;
      }
      setGeneratedKey(data.key);
      setKeyExpiresAt(data.expiresAt);
      setStep("success");
      toast.success("Key generated!");
    } catch (e: any) {
      setError(e?.message || "Network error");
      setStep("error");
    }
  };

  const copyKey = () => {
    if (!generatedKey) return;
    navigator.clipboard.writeText(generatedKey);
    setCopied(true);
    toast.success("Key copied to clipboard");
    setTimeout(() => setCopied(false), 1500);
  };

  const openAdLink = (url: string) => {
    window.open(url, "_blank", "noopener,noreferrer");
    toast.success("Ad opened in new tab. Complete it, then paste your token below.");
  };

  // Blacklisted screen
  if (step === "error" && blackout) {
    const remainingMs = new Date(blackout.expiresAt).getTime() - Date.now();
    const remainingHours = Math.max(0, Math.ceil(remainingMs / (60 * 60 * 1000)));
    return (
      <PublicShell script={script}>
        <Card className="glass-card border-destructive-soft">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <div className="size-16 rounded-2xl bg-destructive-soft flex items-center justify-center mb-4">
              <Ban className="size-8 text-destructive" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Temporarily blacklisted</h2>
            <p className="text-muted-foreground mb-2 max-w-md">
              You are blocked from the /getkey flow for{" "}
              <strong className="text-foreground">{remainingHours}h</strong> due
              to a bypass attempt.
            </p>
            <p className="text-xs text-muted-foreground mb-6">
              Reason: <code className="font-mono">{blackout.reason}</code>
            </p>
            <GradientButton variant="outline" onClick={() => window.location.reload()}>
              Try again later
            </GradientButton>
          </CardContent>
        </Card>
      </PublicShell>
    );
  }

  // Generic error
  if (step === "error") {
    return (
      <PublicShell script={script}>
        <Card className="glass-card border-destructive-soft">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <div className="size-16 rounded-2xl bg-destructive-soft flex items-center justify-center mb-4">
              <AlertCircle className="size-8 text-destructive" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Something went wrong</h2>
            <p className="text-muted-foreground mb-6 max-w-md">
              {error || "An unexpected error occurred. Please try again."}
            </p>
            <GradientButton variant="primary" onClick={() => window.location.reload()}>
              Start over
            </GradientButton>
          </CardContent>
        </Card>
      </PublicShell>
    );
  }

  // Success — key generated
  if (step === "success" && generatedKey) {
    return (
      <PublicShell script={script}>
        <Card className="glass-card border-success-soft">
          <CardContent className="py-8">
            <div className="flex flex-col items-center text-center mb-6">
              <div className="size-16 rounded-2xl bg-[var(--success)] flex items-center justify-center mb-4">
                <CheckCircle2 className="size-8 text-[var(--success-foreground)]" />
              </div>
              <h2 className="text-2xl font-bold mb-1">Your key is ready!</h2>
              <p className="text-muted-foreground text-sm">
                Copy it now — you won&apos;t see this again.
              </p>
            </div>

            <div className="rounded-lg border border-primary-soft bg-primary-soft p-4 mb-4">
              <div className="text-xs text-muted-foreground mb-2 uppercase tracking-wider">
                Your access key
              </div>
              <div className="flex items-center justify-between gap-3">
                <code className="text-lg sm:text-xl font-mono text-primary-hue font-bold break-all text-left">
                  {generatedKey}
                </code>
                <button
                  onClick={copyKey}
                  className="size-9 rounded-md hover:bg-card flex items-center justify-center transition-colors shrink-0"
                >
                  {copied ? (
                    <Check className="size-4 text-success-hue" />
                  ) : (
                    <Copy className="size-4 text-muted-foreground" />
                  )}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="rounded-md bg-muted/40 p-3">
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                  Expires in
                </div>
                <div className="font-semibold">
                  {duration}h
                </div>
                {keyExpiresAt && (
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {new Date(keyExpiresAt).toLocaleString()}
                  </div>
                )}
              </div>
              <div className="rounded-md bg-muted/40 p-3">
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                  Usage limit
                </div>
                <div className="font-semibold">100 validations</div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  Rate-limited per IP
                </div>
              </div>
            </div>

            <div className="mt-6 rounded-md bg-muted/30 p-3 text-xs text-muted-foreground">
              <p className="font-medium text-foreground mb-1">How to use:</p>
              <p>
                Paste this key into your script loader. It will be validated
                against the <code className="font-mono">/api/validate</code>{" "}
                endpoint each time the script runs.
              </p>
            </div>

            <GradientButton
              variant="outline"
              className="w-full mt-4"
              onClick={() => window.location.reload()}
            >
              Get another key
            </GradientButton>
          </CardContent>
        </Card>
      </PublicShell>
    );
  }

  // Generating key
  if (step === "generating") {
    return (
      <PublicShell script={script}>
        <Card className="glass-card">
          <CardContent className="py-12 flex flex-col items-center text-center">
            <div className="size-16 rounded-2xl bg-primary-soft flex items-center justify-center mb-4">
              <Loader2 className="size-8 text-primary-hue animate-spin" />
            </div>
            <h2 className="text-xl font-bold mb-1">Generating your key…</h2>
            <p className="text-muted-foreground text-sm">
              All checkpoints verified — issuing key now
            </p>
          </CardContent>
        </Card>
      </PublicShell>
    );
  }

  // Duration selection
  if (step === "duration") {
    return (
      <PublicShell script={script}>
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="size-5 text-primary-hue" />
              Choose your key duration
            </CardTitle>
            <CardDescription>
              Longer durations require more ad checkpoints to complete.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <DurationOption
              selected={duration === 12}
              onSelect={() => setDuration(12)}
              hours={12}
              ads={1}
              icon={Zap}
              desc="Quick access — complete 1 ad"
            />
            <DurationOption
              selected={duration === 24}
              onSelect={() => setDuration(24)}
              hours={24}
              ads={2}
              icon={ShieldCheck}
              desc="Longer key — complete 2 ads"
            />

            <GradientButton
              variant="primary"
              size="lg"
              className="w-full mt-4"
              onClick={startSession}
              disabled={starting}
            >
              {starting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <ArrowRight className="size-4" />
              )}
              Start — {duration}h key ({duration === 12 ? "1 ad" : "2 ads"})
            </GradientButton>

            <p className="text-xs text-muted-foreground text-center pt-2">
              <ShieldCheck className="inline size-3 mr-1" />
              Bypass attempts are blacklisted for 24 hours.
            </p>
          </CardContent>
        </Card>
      </PublicShell>
    );
  }

  // Checkpoints flow
  if (step === "checkpoints" && session) {
    return (
      <PublicShell script={script}>
        {/* Checkpoint progress header */}
        <Card className="glass-card mb-4">
          <div className="p-5 sm:p-6">
            <div className="flex items-start justify-between gap-4 mb-4">
              <div className="flex items-center gap-3 min-w-0">
                <div className="size-10 rounded-lg bg-primary-soft flex items-center justify-center shrink-0">
                  <Activity className="size-5 text-primary-hue" />
                </div>
                <div className="min-w-0">
                  <div className="font-semibold truncate">
                    {session.checkpointsCompleted} / {session.checkpointsTotal} checkpoints
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {session.durationHours}h key · session expires{" "}
                    {formatDistanceToNow(new Date(session.expiresAt), {
                      addSuffix: true,
                    })}
                  </div>
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-xs text-muted-foreground mb-1">Progress</div>
                <div className="text-sm font-semibold text-primary-hue">
                  {Math.round((session.checkpointsCompleted / session.checkpointsTotal) * 100)}%
                </div>
              </div>
            </div>

            {/* Progress bar */}
            <div className="h-2 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full bg-primary rounded-full transition-all duration-500"
                style={{
                  width: `${(session.checkpointsCompleted / session.checkpointsTotal) * 100}%`,
                }}
              />
            </div>

            {/* Step indicator dots */}
            <div className="flex items-center justify-center gap-2 mt-4">
              {session.checkpoints.map((cp, i) => (
                <div key={i} className="flex items-center">
                  <div
                    className={`size-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                      cp.completed
                        ? "bg-[var(--success)] text-[var(--success-foreground)]"
                        : i === session.checkpointsCompleted
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {cp.completed ? (
                      <Check className="size-4" />
                    ) : (
                      i + 1
                    )}
                  </div>
                  {i < session.checkpoints.length - 1 && (
                    <div
                      className={`w-12 h-0.5 mx-1 ${
                        session.checkpoints[i].completed
                          ? "bg-[var(--success)]"
                          : "bg-muted"
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Checkpoint cards */}
        <div className="space-y-3">
          {session.checkpoints.map((cp, i) => {
            const isCurrent = i === session.checkpointsCompleted && !cp.completed;
            const isLocked = i > session.checkpointsCompleted && !cp.completed;
            return (
              <Card
                key={i}
                className={`glass-card transition-all ${
                  cp.completed
                    ? "border-success-soft"
                    : isCurrent
                    ? "border-primary-soft"
                    : "opacity-60"
                }`}
              >
                <CardContent className="p-5">
                  <div className="flex items-start gap-3 mb-4">
                    <div
                      className={`size-9 rounded-lg flex items-center justify-center shrink-0 ${
                        cp.completed
                          ? "bg-[var(--success)]"
                          : isLocked
                          ? "bg-muted"
                          : "bg-primary-soft"
                      }`}
                    >
                      {cp.completed ? (
                        <Check className="size-4 text-[var(--success-foreground)]" />
                      ) : isLocked ? (
                        <Lock className="size-4 text-muted-foreground" />
                      ) : (
                        <span className="text-sm font-bold text-primary-hue">
                          {i + 1}
                        </span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">
                          Checkpoint {i + 1}
                        </h3>
                        {cp.completed && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-success-soft text-success-hue font-medium">
                            DONE
                          </span>
                        )}
                        {cp.fallback && !cp.completed && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-warning-soft text-warning-hue">
                            Demo mode
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {cp.completed
                          ? `Verified ${cp.verifiedAt ? formatDistanceToNow(new Date(cp.verifiedAt), { addSuffix: true }) : ""}`
                          : isLocked
                          ? "Complete previous checkpoint first"
                          : "Click the button below, complete the ad, then paste your token"}
                      </p>
                    </div>
                  </div>

                  {!cp.completed && !isLocked && (
                    <div className="space-y-3">
                      <GradientButton
                        variant="primary"
                        className="w-full"
                        onClick={() => openAdLink(cp.url)}
                      >
                        <ExternalLink className="size-4" />
                        Go to LootLabs Ad #{i + 1}
                      </GradientButton>

                      <div className="space-y-2">
                        <label className="text-xs font-medium text-muted-foreground">
                          Completion token (starts with <code className="font-mono">LL_</code>)
                        </label>
                        <input
                          type="text"
                          value={tokenInputs[i] || ""}
                          onChange={(e) => {
                            const newTokens = [...tokenInputs];
                            newTokens[i] = e.target.value;
                            setTokenInputs(newTokens);
                          }}
                          placeholder="LL_xxxxxxxxxxxxxxxx"
                          className="w-full px-3 py-2 rounded-md bg-background border border-border text-sm font-mono outline-none focus:border-primary/60"
                        />
                      </div>

                      <GradientButton
                        variant="success"
                        className="w-full"
                        onClick={() => verifyCheckpoint(i)}
                        disabled={
                          submittingCheckpoint === i ||
                          !tokenInputs[i]?.trim()
                        }
                      >
                        {submittingCheckpoint === i ? (
                          <Loader2 className="size-4 animate-spin" />
                        ) : (
                          <ShieldCheck className="size-4" />
                        )}
                        Verify checkpoint
                      </GradientButton>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Generate key button (appears when all done) */}
        {session.checkpointsCompleted >= session.checkpointsTotal && (
          <Card className="glass-card mt-4 border-success-soft fade-in">
            <CardContent className="p-5 text-center">
              <div className="size-12 rounded-xl bg-[var(--success)] flex items-center justify-center mx-auto mb-3">
                <KeyRound className="size-6 text-[var(--success-foreground)]" />
              </div>
              <h3 className="font-bold mb-1">All checkpoints complete!</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Click below to generate your {session.durationHours}h key
              </p>
              <GradientButton
                variant="primary"
                size="lg"
                className="w-full"
                onClick={() => generateKey(session.sessionId)}
              >
                <KeyRound className="size-4" />
                Generate My Key
              </GradientButton>
            </CardContent>
          </Card>
        )}
      </PublicShell>
    );
  }

  // Fallback (should never hit)
  return null;
}

function PublicShell({
  script,
  children,
}: {
  script: Script;
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <header className="glass-nav sticky top-0 z-40">
        <div className="mx-auto flex h-14 max-w-2xl items-center justify-between px-4">
          <a href="/" className="flex items-center gap-2 group">
            <div className="size-7 rounded-md bg-primary flex items-center justify-center">
              <KeyRound className="size-4 text-primary-foreground" />
            </div>
            <span className="text-sm font-bold tracking-tight">
              Key<span className="text-primary-hue">Vault</span>
            </span>
          </a>
          <a
            href="/sign-in"
            className="text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            Creator login →
          </a>
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-4 sm:px-6 py-8">
        {/* Script header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/40 px-3 py-1 text-xs font-medium text-muted-foreground mb-3">
            <Ticket className="size-3 text-primary-hue" />
            /getkey · {script.language}
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold mb-1">{script.name}</h1>
          {script.description && (
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              {script.description}
            </p>
          )}
          {script.user && (
            <p className="text-xs text-muted-foreground mt-2">
              by {script.user.username || script.user.email}
            </p>
          )}
        </div>

        {children}

        <p className="mt-6 text-center text-xs text-muted-foreground">
          <ShieldCheck className="inline size-3 mr-1" />
          Protected by LootLabs ad verification · Bypass attempts blacklisted for 24h
        </p>
      </main>
    </div>
  );
}

function DurationOption({
  selected,
  onSelect,
  hours,
  ads,
  icon: Icon,
  desc,
}: {
  selected: boolean;
  onSelect: () => void;
  hours: number;
  ads: number;
  icon: any;
  desc: string;
}) {
  return (
    <button
      onClick={onSelect}
      className={`relative flex items-start gap-3 p-4 rounded-lg border text-left transition-all w-full ${
        selected
          ? "border-primary bg-primary-soft"
          : "border-border bg-background hover:bg-accent"
      }`}
    >
      <div
        className={`size-10 rounded-lg flex items-center justify-center shrink-0 ${
          selected ? "bg-primary" : "bg-muted"
        }`}
      >
        <Icon
          className={`size-5 ${
            selected ? "text-primary-foreground" : "text-muted-foreground"
          }`}
        />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline gap-2">
          <span className="text-lg font-bold">{hours}h</span>
          <span className="text-xs text-muted-foreground">
            · {ads} ad{ads > 1 ? "s" : ""}
          </span>
        </div>
        <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>
      </div>
      <div
        className={`size-5 rounded-full border-2 shrink-0 mt-0.5 ${
          selected ? "border-primary bg-primary" : "border-border"
        }`}
      >
        {selected && (
          <Check className="size-3 text-primary-foreground m-auto" />
        )}
      </div>
    </button>
  );
}

function KeylessScriptView({ script }: { script: Script }) {
  return (
    <PublicShell script={script}>
      <Card className="glass-card">
        <CardContent className="py-10 text-center">
          <div className="size-16 rounded-2xl bg-success-soft flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="size-8 text-success-hue" />
          </div>
          <h2 className="text-2xl font-bold mb-2">No key required</h2>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            This script is <strong>keyless</strong> — you can use it directly
            without completing any ad gate.
          </p>
          <GradientButton
            variant="primary"
            size="lg"
            onClick={() => {
              navigator.clipboard.writeText(script.content);
              toast.success("Script copied to clipboard");
            }}
          >
            <Copy className="size-4" />
            Copy script
          </GradientButton>
        </CardContent>
      </Card>
    </PublicShell>
  );
}
