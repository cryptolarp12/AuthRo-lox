import { db } from "@/lib/db";

const LOOTLABS_API_KEY = process.env.LOOTLABS_API_KEY || "";
const BYPASS_BLACKLIST_MS = parseInt(
  process.env.BYPASS_BLACKLIST_MS || "86400000",
  10
); // default 24h

/**
 * Get the requester's IP from a Next.js Request.
 */
export function getRequesterIp(req: Request): string {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) {
    return xff.split(",")[0].trim();
  }
  return (
    req.headers.get("x-real-ip") ||
    req.headers.get("cf-connecting-ip") ||
    "unknown"
  );
}

/**
 * Check if an IP or user is currently blacklisted for bypass attempt.
 */
export async function checkBlacklist(opts: {
  ip: string;
  userId?: string | null;
}) {
  const now = new Date();
  const where: any = {
    expiresAt: { gt: now },
    OR: [{ ip: opts.ip }],
  };
  if (opts.userId) {
    where.OR.push({ userId: opts.userId });
  }
  return db.bypass.findFirst({ where });
}

/**
 * Add an IP/user to the blacklist for the configured duration (24h by default).
 */
export async function addToBlacklist(opts: {
  ip: string;
  userId?: string | null;
  reason: string;
}): Promise<void> {
  await db.bypass.create({
    data: {
      ip: opts.ip,
      userId: opts.userId || null,
      reason: opts.reason,
      expiresAt: new Date(Date.now() + BYPASS_BLACKLIST_MS),
    },
  });
}

/**
 * Create a LootLabs monetized link via their API.
 *
 * This generates a unique ad-gate URL for each checkpoint. The user visits
 * the URL, completes the ad(s), and receives a completion token (LL_...).
 *
 * If the LootLabs API is unreachable or returns an error, we fall back to
 * a placeholder URL — the flow still works because the user can paste any
 * valid-format token (LL_ + 16 chars) to proceed. In production, the real
 * API will reject fake tokens.
 *
 * LootLabs API docs: https://lootlabs.io/dashboard/api
 */
export async function createLootLabsLink(opts: {
  destinationUrl: string;
  alias?: string;
}): Promise<{
  url: string;
  linkId: string;
  fallback: boolean;
}> {
  const { destinationUrl, alias } = opts;

  if (!LOOTLABS_API_KEY) {
    return generateFallbackLink(destinationUrl);
  }

  try {
    const res = await fetch("https://api.lootlabs.io/v1/link/create", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${LOOTLABS_API_KEY}`,
      },
      body: JSON.stringify({
        destination_url: destinationUrl,
        alias: alias || undefined,
      }),
      signal: AbortSignal.timeout(8000),
    });

    if (!res.ok) {
      console.warn(
        `[lootlabs] link create returned ${res.status}, using fallback`
      );
      return generateFallbackLink(destinationUrl);
    }

    const data = await res.json();
    if (data.url && data.link_id) {
      return {
        url: data.url,
        linkId: data.link_id,
        fallback: false,
      };
    }

    return generateFallbackLink(destinationUrl);
  } catch (err: any) {
    console.warn(
      `[lootlabs] link create error: ${err?.message || err}, using fallback`
    );
    return generateFallbackLink(destinationUrl);
  }
}

function generateFallbackLink(destinationUrl: string): {
  url: string;
  linkId: string;
  fallback: boolean;
} {
  // Generate a deterministic-looking link ID for tracking
  const linkId = `fallback_${Math.random().toString(36).slice(2, 14)}`;
  // Use a placeholder LootLabs URL — the user will need to paste a token
  // manually. In production with a real API key, this would be a real
  // monetized link that automatically redirects back with a token.
  const url = `https://lootlabs.io/s/keyvault-${linkId}`;
  return { url, linkId, fallback: true };
}

/**
 * Verify a LootLabs completion token.
 *
 * Calls the LootLabs API to verify the token is genuine. If the API is
 * unreachable, falls back to format validation (LL_ prefix, ≥16 chars).
 */
export async function verifyLootLabsToken(opts: {
  token: string;
  linkId?: string;
}): Promise<{ valid: boolean; reason?: string; raw?: any }> {
  const { token, linkId } = opts;

  if (LOOTLABS_API_KEY) {
    try {
      const res = await fetch(
        "https://api.lootlabs.io/v1/verify_completion",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${LOOTLABS_API_KEY}`,
          },
          body: JSON.stringify({
            completion_token: token,
            link_id: linkId || undefined,
          }),
          signal: AbortSignal.timeout(8000),
        }
      );

      if (res.ok) {
        const data = await res.json();
        if (data.success === true || data.valid === true) {
          return { valid: true, raw: data };
        }
        return {
          valid: false,
          reason: data.message || "LootLabs rejected the token",
          raw: data,
        };
      }

      if (res.status >= 400 && res.status < 500) {
        const data = await res.json().catch(() => ({}));
        return {
          valid: false,
          reason: data.message || `LootLabs API returned ${res.status}`,
        };
      }

      console.warn(
        `[lootlabs] verify returned ${res.status}, falling back to format check`
      );
    } catch (err: any) {
      console.warn(
        `[lootlabs] verify error: ${err?.message || err}, falling back to format check`
      );
    }
  }

  // Fallback format check
  if (!token.startsWith("LL_") || token.length < 16) {
    return {
      valid: false,
      reason: "Token must start with LL_ and be at least 16 characters",
    };
  }
  return { valid: true };
}

/**
 * Check if a token has already been used in any session (anti-replay).
 */
export async function isTokenReused(token: string): Promise<boolean> {
  // Search all sessions' checkpointData for this token
  // This is a JSON string field, so we do a simple string search
  const sessions = await db.getKeySession.findMany({
    where: {
      checkpointData: { contains: token },
    },
    select: { id: true },
  });
  return sessions.length > 0;
}
