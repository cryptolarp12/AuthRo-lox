"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useApp } from "@/lib/store";
import { GradientButton } from "./GradientButton";
import { KeyGenModal } from "./KeyGenModal";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import {
  ArrowLeft,
  Save,
  Loader2,
  FileCode2,
  KeyRound,
  Calendar,
  Globe,
  Lock,
  Pencil,
  Check,
  Copy,
  Ticket,
  Plus,
  ShieldCheck,
} from "./icons";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

type Script = {
  id: string;
  name: string;
  description: string | null;
  language: string;
  version: string;
  isPublic: boolean;
  keyRequired: boolean;
  content: string;
  createdAt: string;
  updatedAt: string;
  keys: {
    id: string;
    key: string;
    status: string;
    expiresAt: string | null;
    usageLimit: number | null;
    usageCount: number;
    note: string | null;
  }[];
  _count: { keys: number };
};

export function ScriptEditorView() {
  const { selectedScriptId, setView } = useApp();
  const [script, setScript] = useState<Script | null>(null);
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [genOpen, setGenOpen] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const editorRef = useRef<HTMLTextAreaElement | null>(null);

  const load = useCallback(async () => {
    if (!selectedScriptId) {
      setView("scripts");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`/api/scripts/${selectedScriptId}`, {
        cache: "no-store",
      });
      if (!res.ok) {
        toast.error("Failed to load script");
        setView("scripts");
        return;
      }
      const data = await res.json();
      setScript(data.script);
      setContent(data.script.content);
      setName(data.script.name);
      setDescription(data.script.description || "");
    } finally {
      setLoading(false);
    }
  }, [selectedScriptId, setView]);

  useEffect(() => {
    load();
  }, [load]);

  // Reset dirty when content/name/description changes externally
  useEffect(() => {
    setDirty(false);
  }, [script?.updatedAt]);

  const handleSave = async () => {
    if (!script) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/scripts/${script.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          description,
          content,
          keyRequired: script.keyRequired,
          version: bumpVersion(script.version),
        }),
      });
      if (!res.ok) {
        const data = await res.json();
        toast.error(data.error || "Failed to save");
        return;
      }
      const data = await res.json();
      setScript({ ...script, ...data.script, keys: script.keys, _count: script._count });
      setDirty(false);
      toast.success("Saved — version bumped to " + data.script.version);
    } finally {
      setSaving(false);
    }
  };

  const copyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    setCopiedKey(key);
    toast.success("Key copied");
    setTimeout(() => setCopiedKey(null), 1500);
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
        <div className="h-96 rounded-xl shimmer" />
      </div>
    );
  }

  if (!script) {
    return null;
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-6">
      {/* Top bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div className="flex items-center gap-3">
          <GradientButton
            variant="ghost"
            size="icon"
            onClick={() => setView("scripts")}
            aria-label="Back to scripts"
          >
            <ArrowLeft className="size-5" />
          </GradientButton>
          <div className="size-11 rounded-lg gradient-secondary flex items-center justify-center shrink-0">
            <FileCode2 className="size-5 text-white" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold truncate">{name}</h1>
              <Badge
                variant="outline"
                className="border-primary/30 bg-primary/10 text-primary"
              >
                v{script.version}
              </Badge>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
              <span className="font-mono">{script.language}</span>
              <span className="flex items-center gap-1">
                {script.isPublic ? (
                  <>
                    <Globe className="size-3" /> Public
                  </>
                ) : (
                  <>
                    <Lock className="size-3" /> Private
                  </>
                )}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="size-3" />
                Updated{" "}
                {formatDistanceToNow(new Date(script.updatedAt), {
                  addSuffix: true,
                })}
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <GradientButton
            variant="outline"
            onClick={() => setGenOpen(true)}
          >
            <Plus className="size-4" />
            Generate keys
          </GradientButton>
          <GradientButton
            variant="primary"
            onClick={handleSave}
            disabled={!dirty || saving}
          >
            {saving ? (
              <Loader2 className="size-4 animate-spin" />
            ) : dirty ? (
              <Save className="size-4" />
            ) : (
              <Check className="size-4" />
            )}
            {dirty ? "Save" : "Saved"}
          </GradientButton>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Editor */}
        <div className="lg:col-span-2">
          <Card className="glass-card overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Pencil className="size-4 text-primary" />
                  Code editor
                </CardTitle>
                {dirty && (
                  <span className="text-xs text-yellow-500 flex items-center gap-1">
                    <span className="size-1.5 rounded-full bg-yellow-500 pulse-soft" />
                    Unsaved changes
                  </span>
                )}
              </div>
              <CardDescription>
                Edits auto-bump the patch version on save.
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="flex items-center gap-2 px-4 py-2 border-b border-border bg-background/40">
                <div className="size-2.5 rounded-full bg-red-500/70" />
                <div className="size-2.5 rounded-full bg-yellow-500/70" />
                <div className="size-2.5 rounded-full bg-green-500/70" />
                <span className="ml-2 text-xs text-muted-foreground font-mono">
                  script.{script.language === "lua" ? "lua" : script.language === "javascript" ? "js" : script.language === "python" ? "py" : "txt"}
                </span>
              </div>
              <div className="grid grid-cols-[auto_1fr] font-mono text-sm leading-6 bg-[#1e1e1e]">
                {/* Line numbers */}
                <pre
                  className="text-muted-foreground/40 text-right select-none py-3 pl-3 pr-2"
                  aria-hidden="true"
                >
                  {content.split("\n").map((_, i) => (
                    <div key={i}>{i + 1}</div>
                  ))}
                </pre>
                {/* Editor textarea (transparent, overlays the highlighted preview) */}
                <div className="relative">
                  <textarea
                    ref={editorRef}
                    value={content}
                    onChange={(e) => {
                      setContent(e.target.value);
                      setDirty(true);
                    }}
                    spellCheck={false}
                    className="absolute inset-0 w-full h-full bg-transparent text-transparent caret-white resize-none outline-none py-3 pr-4 pl-2 overflow-auto scrollbar-custom"
                    style={{
                      fontFamily:
                        "var(--font-geist-mono), ui-monospace, monospace",
                    }}
                  />
                  <pre
                    className="py-3 pr-4 pl-2 pointer-events-none overflow-auto scrollbar-custom min-h-[400px]"
                    aria-hidden="true"
                  >
                    <SyntaxHighlighter
                      language={script.language === "text" ? "text" : script.language}
                      style={vscDarkPlus}
                      customStyle={{
                        background: "transparent",
                        padding: 0,
                        margin: 0,
                        fontSize: "14px",
                        fontFamily:
                          "var(--font-geist-mono), ui-monospace, monospace",
                      }}
                      codeTagProps={{
                        style: {
                          fontFamily:
                            "var(--font-geist-mono), ui-monospace, monospace",
                        },
                      }}
                    >
                      {content + "\n"}
                    </SyntaxHighlighter>
                  </pre>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Description editor */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5">
                <label className="text-xs text-muted-foreground">Name</label>
                <input
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    setDirty(true);
                  }}
                  className="w-full px-3 py-2 rounded-md bg-background border border-border text-sm outline-none focus:border-primary/60"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs text-muted-foreground">
                  Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) => {
                    setDescription(e.target.value);
                    setDirty(true);
                  }}
                  rows={4}
                  className="w-full px-3 py-2 rounded-md bg-background border border-border text-sm outline-none focus:border-primary/60 resize-none"
                />
              </div>

              {/* Key system toggle */}
              <div className="rounded-md border border-border bg-muted/30 p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <label className="text-sm font-medium">
                      Require a key
                    </label>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {script.keyRequired
                        ? "Users complete /getkey ad flow to receive a key."
                        : "Keyless — users access the script directly."}
                    </p>
                  </div>
                  <Switch
                    checked={script.keyRequired}
                    onCheckedChange={(checked) => {
                      // Update locally + save immediately
                      setScript({ ...script, keyRequired: checked });
                      setDirty(true);
                    }}
                  />
                </div>
                {script.isPublic && (
                  <a
                    href={`/getkey/${script.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-xs text-primary-hue hover:underline"
                  >
                    View /getkey page →
                  </a>
                )}
              </div>

              <div className="pt-2 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
                <span>Script ID</span>
                <code className="font-mono text-[10px]">{script.id}</code>
              </div>
            </CardContent>
          </Card>

          {/* Quick actions */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Quick actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <button
                onClick={() => setGenOpen(true)}
                className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-background/40 transition-colors text-left"
              >
                <div className="size-8 rounded-md gradient-primary flex items-center justify-center shrink-0">
                  <Plus className="size-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium">Generate keys</div>
                  <div className="text-xs text-muted-foreground">Bound to this script</div>
                </div>
              </button>
              <button
                onClick={() => setView("getkey")}
                className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-background/40 transition-colors text-left"
              >
                <div className="size-8 rounded-md gradient-accent flex items-center justify-center shrink-0">
                  <Ticket className="size-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium">/getkey flow</div>
                  <div className="text-xs text-muted-foreground">
                    Simulate ad-bypass for this script
                  </div>
                </div>
              </button>
              <button
                onClick={() => setView("validate")}
                className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-background/40 transition-colors text-left"
              >
                <div className="size-8 rounded-md gradient-success flex items-center justify-center shrink-0">
                  <ShieldCheck className="size-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium">Test validator</div>
                  <div className="text-xs text-muted-foreground">
                    Validate a key against this script
                  </div>
                </div>
              </button>
            </CardContent>
          </Card>

          {/* Recent keys */}
          <Card className="glass-card">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <KeyRound className="size-4 text-primary" />
                  Recent keys
                </CardTitle>
                <span className="text-xs text-muted-foreground">
                  {script._count?.keys || 0} total
                </span>
              </div>
            </CardHeader>
            <CardContent>
              {script.keys && script.keys.length > 0 ? (
                <div className="space-y-2 max-h-64 overflow-y-auto scrollbar-custom">
                  {script.keys.map((k) => (
                    <div
                      key={k.id}
                      className="flex items-center justify-between gap-2 p-2 rounded-md bg-background/40 border border-border"
                    >
                      <code className="text-xs font-mono gradient-primary-text font-semibold truncate">
                        {k.key}
                      </code>
                      <button
                        onClick={() => copyKey(k.key)}
                        className="size-6 rounded hover:bg-card flex items-center justify-center shrink-0"
                        aria-label="Copy"
                      >
                        {copiedKey === k.key ? (
                          <Check className="size-3 text-green-500" />
                        ) : (
                          <Copy className="size-3 text-muted-foreground" />
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground text-center py-4">
                  No keys bound to this script yet.
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <KeyGenModal
        open={genOpen}
        onClose={() => setGenOpen(false)}
        scripts={[{ id: script.id, name: script.name }]}
        defaultScriptId={script.id}
        onGenerated={() => load()}
      />
    </div>
  );
}

function bumpVersion(v: string): string {
  const parts = v.split(".").map((n) => parseInt(n, 10) || 0);
  while (parts.length < 3) parts.push(0);
  parts[2] += 1;
  return parts.join(".");
}
