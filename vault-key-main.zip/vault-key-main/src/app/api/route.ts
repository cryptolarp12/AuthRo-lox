import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    service: "KeyVault",
    version: "1.0.0",
    status: "ok",
    auth: "Clerk",
    endpoints: {
      public: [
        "POST /api/validate",
        "POST /api/clerk/webhook",
        "POST /api/getkey/start",
        "POST /api/getkey/checkpoint",
        "POST /api/getkey/generate",
        "GET /api/getkey/status",
      ],
      protected: [
        "GET /api/me",
        "GET /api/keys",
        "POST /api/keys",
        "DELETE /api/keys",
        "GET /api/keys/[id]",
        "PATCH /api/keys/[id]",
        "DELETE /api/keys/[id]",
        "GET /api/scripts",
        "POST /api/scripts",
        "GET /api/scripts/[id]",
        "PATCH /api/scripts/[id]",
        "DELETE /api/scripts/[id]",
        "GET /api/stats",
      ],
    },
  });
}
